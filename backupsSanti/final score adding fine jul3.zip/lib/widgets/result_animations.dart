// lib/widgets/result_animations.dart

import 'dart:math';
import 'package:flutter/material.dart';
import 'package:simple_animations/simple_animations.dart';

// 1. "Bullseye!" Text Animation (for a score of 6)
class BullseyeAnimation extends StatelessWidget {
  const BullseyeAnimation({super.key});

  @override
  Widget build(BuildContext context) {
    return PlayAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: const Duration(milliseconds: 1500),
      builder: (context, value, child) {
        return Transform.scale(
          scale: 1.0 + (0.5 * sin(value * pi * 3)), // Pop and bounce effect
          child: Opacity(
            opacity: 1.0 - value, // Fade out
            child: child,
          ),
        );
      },
      child: Text(
        'Bullseye!',
        style: TextStyle(
          fontSize: 60,
          fontWeight: FontWeight.bold,
          color: Colors.amber.shade700,
          shadows: const [
            Shadow(blurRadius: 10, color: Colors.black54),
          ],
        ),
      ),
    );
  }
}

// 2. Thumbs-Up Animation (for a score of 3-4)
class ThumbsUpAnimation extends StatelessWidget {
  const ThumbsUpAnimation({super.key});

  @override
  Widget build(BuildContext context) {
    return const ParticleStream(
      particleCount: 15,
      icon: Icons.recommend, // A more stylized thumbs-up icon
      color: Colors.lightBlueAccent,
    );
  }
}

// 3. Gentle Poof Animation (for a score of 1-2)
class GentlePoofAnimation extends StatelessWidget {
  const GentlePoofAnimation({super.key});

  @override
  Widget build(BuildContext context) {
    return PlayAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: const Duration(milliseconds: 600),
      builder: (context, value, child) {
        return Opacity(
          opacity: 1.0 - value, // Fade out
          child: Transform.scale(
            scale: 1.0 + value * 2, // Scale up
            child: child,
          ),
        );
      },
      child: Icon(
        Icons.cloud_circle_outlined,
        color: Colors.grey.withOpacity(0.5),
        size: 150,
      ),
    );
  }
}

// 4. Tumbleweed Animation (for a score of 0)
// 4. Tumbleweed Animation (for a score of 0) - NOW MOVES ACROSS SCREEN
class TumbleweedAnimation extends StatefulWidget {
  const TumbleweedAnimation({super.key});

  @override
  State<TumbleweedAnimation> createState() => _TumbleweedAnimationState();
}

class _TumbleweedAnimationState extends State<TumbleweedAnimation>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PlayAnimationBuilder<double>(
      tween: Tween(begin: -1.0, end: 1.0), // Animate from left edge to right edge
      duration: const Duration(seconds: 4),
      builder: (context, value, child) {
        // Use Alignment to position it across the entire screen
        return Align(
          alignment: Alignment(value, 0.8), // Animate horizontal alignment
          child: child,
        );
      },
      child: RotationTransition(
        turns: _controller,
        // This is a "tumbleweed" made of leaf emojis
        child: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('🍂', style: TextStyle(fontSize: 40)),
            Text('🍂', style: TextStyle(fontSize: 60)),
            Text('🍂', style: TextStyle(fontSize: 40)),
          ],
        ),
      ),
    );
  }
}

// --- NEW Helper Widget for Particle Streams ---
class ParticleStream extends StatelessWidget {
  final int particleCount;
  final IconData icon;
  final Color color;
  const ParticleStream({super.key, required this.particleCount, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: List.generate(
        particleCount,
        (index) => PlayAnimationBuilder<double>(
          delay: Duration(milliseconds: Random().nextInt(4000)),
          tween: Tween(begin: 0.0, end: 1.0),
          duration: Duration(milliseconds: Random().nextInt(3000) + 2000),
          builder: (context, value, child) {
            return Transform.translate(
              offset: Offset(
                (Random().nextDouble() * 2 - 1) * (MediaQuery.of(context).size.width / 2),
                (1.1 - value * 2.2) * (MediaQuery.of(context).size.height / 2),
              ),
              child: Transform.rotate(
                angle: Random().nextDouble() * 2 * pi,
                child: Opacity(opacity: 1.0 - value, child: child),
              ),
            );
          },
          child: Icon(icon, color: color, size: 40),
        ),
      ),
    );
  }
}