// lib/screens/ready_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/player_status.dart';
import '../screens/dialog_helpers.dart';
import '../services/firebase_service.dart';
import '../theme/app_theme.dart'; // Import the theme for colors

class ReadyScreen extends StatelessWidget {
  static const routeName = '/ready';
  final String roomId;
  const ReadyScreen({super.key, required this.roomId});
  
  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Game Lobby'),
        automaticallyImplyLeading: false, // Prevents a back button
        actions: [
          IconButton(
            // *** ICON STYLE UPDATE ***
            icon: const Icon(Icons.exit_to_app_rounded),
            onPressed: () => showExitConfirmationDialog(context, roomId),
          ),
        ],
      ),
      body: StreamBuilder<ReadyScreenViewModel>(
        stream: fb.listenToReadyScreenViewModel(roomId),
        builder: (ctx, vmSnap) {
          if (!vmSnap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final viewModel = vmSnap.data!;
          final players = viewModel.players;
          final me = viewModel.me;

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Text('Room Code:', style: textTheme.bodyMedium),
                const SizedBox(height: 4),
                SelectableText(
                  roomId, 
                  style: textTheme.displayMedium,
                ),
                const SizedBox(height: 24),
                Expanded(
                  child: ListView.builder(
                    itemCount: players.length,
                    itemBuilder: (context, index) {
                      // *** NEW: PlayerLobbyCard with animation ***
                      return PlayerLobbyCard(player: players[index]);
                    },
                  ),
                ),
                const SizedBox(height: 12),
                if (me != null)
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => fb.setReady(roomId, !me.ready),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: me.ready ? AppColors.surface : AppColors.accent,
                      ),
                      child: Text(me.ready ? 'Cancel Ready' : 'I\'m Ready'),
                    ),
                  ),
                const SizedBox(height: 16),
                if (viewModel.isHost)
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: viewModel.allPlayersReady
                          ? () => fb.startRound(roomId)
                          : null, // Disabled if not all are ready
                      // *** FIX: Correctly style the disabled button ***
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.accentVariant,
                        disabledBackgroundColor: AppColors.surface.withOpacity(0.5),
                        disabledForegroundColor: Colors.grey,
                      ),
                      child: Text(viewModel.allPlayersReady ? 'All Ready — Start Round' : 'Waiting For Players...'),
                    ),
                  ),
                if (!viewModel.isHost && !viewModel.allPlayersReady)
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text('Waiting for players to get ready...', style: textTheme.labelMedium),
                  ),
                if (!viewModel.isHost && viewModel.allPlayersReady)
                   Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text('All ready! Waiting for host to start...', style: textTheme.labelMedium?.copyWith(color: AppColors.accent)),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}


// New widget for displaying players in the lobby with animations
class PlayerLobbyCard extends StatelessWidget {
  final PlayerStatus player;

  const PlayerLobbyCard({
    super.key,
    required this.player,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        leading: AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          transitionBuilder: (child, animation) {
            return ScaleTransition(
              scale: animation,
              child: child,
            );
          },
          child: Icon(
            player.ready ? Icons.check_circle_rounded : Icons.person_rounded,
            key: ValueKey<bool>(player.ready), // Important for AnimatedSwitcher
            color: player.ready ? AppColors.success : AppColors.accent,
            size: 32,
          ),
        ),
        title: Text(player.displayName, style: Theme.of(context).textTheme.titleLarge),
        trailing: Icon(
          Icons.circle,
          size: 12,
          color: player.online ? AppColors.success : AppColors.error,
        ),
      ),
    );
  }
}
