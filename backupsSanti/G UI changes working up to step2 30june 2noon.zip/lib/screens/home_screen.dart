// lib/screens/home_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/firebase_service.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  static const routeName = '/';
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _roomCtrl = TextEditingController();
  bool _loading = false;
  String? _error;

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mind Drift'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_rounded), // UPDATED
            onPressed: () {
              Navigator.pushNamed(context, SettingsScreen.routeName);
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            if (_error != null) Text(_error!, style: const TextStyle(color: Colors.red)),
            ElevatedButton(
              onPressed: _loading
                  ? null
                  : () async {
                      setState(() => _loading = true);
                      try {
                        final settings = await fb.fetchRoomCreationSettings();
                        // This just updates the database. The RoomNavigator will see the change.
                        await fb.createRoom(
                            settings['saboteurEnabled'] ?? false,
                            settings['diceRollEnabled']  ?? false,
                        );
                        // NO MORE Navigator calls here.
                      } catch(e) {
                          setState(() {
                            _error = "Error: $e";
                            _loading = false;
                          });
                      }
                    },
              child: _loading
                  ? const CircularProgressIndicator()
                  : const Text('Create Room'),
            ),
            const SizedBox(height: 24),
            TextField(
              controller: _roomCtrl,
              decoration: const InputDecoration(labelText: 'Enter Room ID'),
              textCapitalization: TextCapitalization.characters,
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _loading
                  ? null
                  : () async {
                      setState(() => _loading = true);
                      try {
                        final code = _roomCtrl.text.trim().toUpperCase();
                        // ... (error handling for empty code, room not found, etc.)
                        await fb.joinRoom(code);
                        // NO MORE Navigator calls here.
                      } catch (e) {
                          setState(() {
                            _error = "Error joining room: $e";
                            _loading = false;
                          });
                      }
                    },
              child: _loading
                  ? const CircularProgressIndicator()
                  : const Text('Join Room'),
            ),
          ],
        ),
      ),
    );
  }
}