// lib/screens/waiting_clue_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:wavelength_clone_fresh/screens/dialog_helpers.dart';
import '../services/firebase_service.dart';
import 'guess_round_screen.dart';
import '../models/round.dart'; // Import Round model
// Import for navigating back to home
// Import for navigating to scoreboard

class WaitingClueScreen extends StatefulWidget {
  static const routeName = '/waiting';
  final String roomId;
  const WaitingClueScreen({super.key, required this.roomId});

  @override
  State<WaitingClueScreen> createState() => _WaitingClueScreenState();
}

class _WaitingClueScreenState extends State<WaitingClueScreen> {
  bool _showingLastPlayerDialog = false;

  @override
  void initState() {
    super.initState();
    _setupPlayerListeners();
  }

  void _setupPlayerListeners() {
    // Listen for player departures to show toast messages
    context.read<FirebaseService>().listenForPlayerDepartures(widget.roomId).listen((playerName) {
      if (playerName != null && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$playerName has exited the room.'),
            duration: const Duration(seconds: 2),
          ),
        );
      }
    });

    // Listen for last player standing scenario
    context.read<FirebaseService>().listenToLastPlayerStatus(widget.roomId).listen((status) async {
      final onlinePlayerCount = status['onlinePlayerCount'] as int;
      final isLastPlayer = status['isLastPlayer'] as bool;
      final currentUserDisplayName = status['currentUserDisplayName'] as String;
      final roomId = widget.roomId;

      // Get room data to check if current user is creator and it's the very beginning
      final roomSnap = await context.read<FirebaseService>().roomDocRef(roomId).get();
      final roomData = roomSnap.data();
      final isCreator = roomData?['creator'] == context.read<FirebaseService>().currentUserUid;
      final currentRoundNumber = roomData?['currentRoundNumber'] as int? ?? 0;

      // Suppress dialog if creator and it's the very first round (currentRoundNumber is 0 or 1)
      final isInitialRoomCreation = isCreator && currentRoundNumber <= 1;

      if (isLastPlayer && onlinePlayerCount == 1 && !_showingLastPlayerDialog && mounted && !isInitialRoomCreation) {
        setState(() {
          _showingLastPlayerDialog = true;
        });
        showLastPlayerDialog(context, currentUserDisplayName, widget.roomId);
      } else if (!isLastPlayer && onlinePlayerCount > 1 && _showingLastPlayerDialog) {
        // If more players join, dismiss the dialog if it's showing
        if (Navigator.of(context).canPop()) {
          Navigator.of(context).pop();
        }
        setState(() {
          _showingLastPlayerDialog = false;
        });
      }
    });
  }


  

  // Helper to get a string representation of the effect
  String _getEffectDescription(Effect? effect) {
    if (effect == null || effect == Effect.none) {
      return '';
    }
    switch (effect) {
      case Effect.doubleScore: return 'Double Score!';
      case Effect.halfScore: return 'Half Score!';
      case Effect.token: return 'Navigator gets a Token!';
      case Effect.reverseSlider: return 'Reverse Slider!';
      case Effect.noClue: return 'No Clue!';
      case Effect.blindGuess: return 'Blind Guess!';
      default: return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();
    final roomId = widget.roomId;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Waiting for Clue'),
        actions: [
          IconButton(
            icon: const Icon(Icons.exit_to_app),
            onPressed: () => showExitConfirmationDialog(context, widget.roomId),
          ),
        ],
      ),
      body: StreamBuilder<Round>(
        stream: fb.listenCurrentRound(roomId), // Now streams Round object
        builder: (ctx, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final currentRound = snap.data!;
          final clue = currentRound.clue ?? '';
          final effect = currentRound.effect; // Get the effect
          final effectDescription = _getEffectDescription(effect);

          if (clue.isEmpty) {
            return Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                if (effect != null && effect != Effect.none)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16.0),
                    child: Text(
                      'Effect: $effectDescription',
                      style: TextStyle(fontSize: 18, fontStyle: FontStyle.italic, color: Colors.deepOrange.shade700, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                  ),
                const SizedBox(height: 16),
                const Center(child: Text('Navigator is thinking…', style: TextStyle(fontSize: 18))),
                const SizedBox(height: 20),
                const CircularProgressIndicator(),
              ],
            );
          }

          // Once clue appears, go to GuessRoundScreen
          WidgetsBinding.instance.addPostFrameCallback((_) {
            Navigator.pushReplacementNamed(
              context,
              GuessRoundScreen.routeName,
              arguments: roomId,
            );
          });
          return const SizedBox();
        },
      ),
    );
  }
}
