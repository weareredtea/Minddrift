// lib/main.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';

import 'firebase_options.dart';
import 'services/firebase_service.dart';
import 'models/round.dart';
import 'screens/home_screen.dart';
import 'screens/ready_screen.dart';
import 'screens/setup_round_screen.dart';
import 'screens/waiting_clue_screen.dart';
import 'screens/guess_round_screen.dart';
import 'screens/result_screen.dart';
import 'screens/match_summary_screen.dart';
import 'screens/dice_roll_screen.dart';
import 'screens/settings_screen.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => FirebaseService(),
      child: MaterialApp(
        title: 'Wavelength Clone',
        theme: ThemeData(useMaterial3: true),
        // The entire app is now controlled by the RoomNavigator
        home: const RoomNavigator(),
        // We define routes here for any secondary screens that might be pushed
        // on top of the main flow (like Settings).
        routes: {
          SettingsScreen.routeName: (_) => const SettingsScreen(),
        },
      ),
    );
  }
}

/// RoomNavigator is now the single source of truth for navigation.
/// It listens to the database and shows the correct screen.
class RoomNavigator extends StatelessWidget {
  const RoomNavigator({super.key});

  @override
  Widget build(BuildContext context) {
    final fb = context.watch<FirebaseService>();

    // Stage 1: Check if a user is signed in.
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, authSnapshot) {
        if (authSnapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (!authSnapshot.hasData) {
          return const HomeScreen();
        }

        // Stage 2: Check if the user is in a room.
        return StreamBuilder<String?>(
          stream: fb.listenCurrentUserRoomId(),
          builder: (context, roomSnapshot) {
            final roomId = roomSnapshot.data;
            if (roomId == null) {
              return const HomeScreen();
            }

            // Stage 3: Listen to the room's status to show the correct game screen.
            return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
              stream: fb.roomDocRef(roomId).snapshots(),
              builder: (context, gameSnapshot) {
                if (!gameSnapshot.hasData || !gameSnapshot.data!.exists) {
                  // If the room is deleted, go home.
                  return const HomeScreen();
                }

                final roomStatus = gameSnapshot.data!.data()?['status'] as String? ?? 'lobby';
                
                switch (roomStatus) {
                  case 'lobby':
                  case 'ready_phase':
                    return ReadyScreen(roomId: roomId);
                  case 'dice_roll':
                    return DiceRollScreen(roomId: roomId);
                  case 'clue_submission':
                    // We need to know if we are the Navigator or a Seeker
                    return StreamBuilder<Role>(
                      stream: fb.listenMyRole(roomId),
                      builder: (context, roleSnapshot) {
                        final myRole = roleSnapshot.data;
                        if(myRole == Role.Navigator) {
                          return SetupRoundScreen(roomId: roomId);
                        } else {
                          return WaitingClueScreen(roomId: roomId);
                        }
                      },
                    );
                  case 'guessing':
                    return GuessRoundScreen(roomId: roomId);
                  case 'round_end':
                    return ResultScreen(roomId: roomId);
                  case 'match_end':
                    return MatchSummaryScreen(roomId: roomId);
                  default:
                    return const HomeScreen();
                }
              },
            );
          },
        );
      },
    );
  }
}