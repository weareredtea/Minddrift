// lib/widgets/slider_dial.dart

import 'package:flutter/material.dart';
import 'dart:math' as math;

class SliderDial extends StatelessWidget {
  final double value;
  final int divisions;
  final ValueChanged<double> onChanged;
  final bool showValue; // New parameter to control visibility of the label

  const SliderDial({
    Key? key,
    required this.value,
    required this.divisions,
    required this.onChanged,
    this.showValue = true, // Default to true
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Slider(
      value: value,
      divisions: divisions,
      min: 0,
      max: 100,
      label: showValue ? value.round().toString() : null, // Conditionally show label
      onChanged: onChanged,
    );
  }
}
