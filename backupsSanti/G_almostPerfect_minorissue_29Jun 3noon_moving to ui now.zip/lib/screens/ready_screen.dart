// lib/screens/ready_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:wavelength_clone_fresh/screens/dialog_helpers.dart';
import '../screens/dialog_helpers.dart';
import '../services/firebase_service.dart';

class ReadyScreen extends StatelessWidget {
  static const routeName = '/ready';
  final String roomId;
  const ReadyScreen({Key? key, required this.roomId}) : super(key: key);
  
  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Get Ready'),
        actions: [
          IconButton(
            icon: const Icon(Icons.exit_to_app),
            onPressed: () => showExitConfirmationDialog(context, roomId),
          ),
        ],
      ),
      body: StreamBuilder<ReadyScreenViewModel>(
        stream: fb.listenToReadyScreenViewModel(roomId),
        builder: (ctx, vmSnap) {
          if (!vmSnap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final viewModel = vmSnap.data!;
          final players = viewModel.players;
          final me = viewModel.me;

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Text('Room Code: $roomId', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),
                Expanded(
                  child: ListView.builder(
                    itemCount: players.length,
                    itemBuilder: (context, index) {
                      // ... (player list UI is the same)
                    },
                  ),
                ),
                const SizedBox(height: 12),
                if (me != null)
                  ElevatedButton(
                    onPressed: () => fb.setReady(roomId, !me.ready),
                    // ... (button style)
                    child: Text(me.ready ? 'Cancel Ready' : 'I\'m Ready'),
                  ),
                const SizedBox(height: 16),
                if (viewModel.isHost)
                  ElevatedButton(
                    onPressed: viewModel.allPlayersReady
                        ? () {
                            // This button JUST changes the data. That's it.
                            fb.startRound(roomId);
                          }
                        : null,
                    // ... (button style and text)
                    child: Text(viewModel.allPlayersReady ? 'All Ready — Start Round' : 'Waiting For Players...'),
                  ),
                if (!viewModel.isHost)
                  Text(viewModel.allPlayersReady ? 'Waiting for the host...' : 'Waiting for players...'),
                const SizedBox(height: 16),
              ],
            ),
          );
        },
      ),
    );
  }
}