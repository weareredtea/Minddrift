// lib/main.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';

import 'firebase_options.dart';
import 'services/firebase_service.dart';
import 'screens/home_screen.dart';
import 'screens/lobby_screen.dart';
import 'screens/ready_screen.dart';
import 'screens/setup_round_screen.dart';
import 'screens/waiting_clue_screen.dart';
import 'screens/guess_round_screen.dart';
import 'screens/result_screen.dart';
import 'screens/scoreboard_screen.dart';
import 'screens/match_summary_screen.dart';
import 'screens/settings_screen.dart'; // Make sure settings screen is imported

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => FirebaseService(),
      child: MaterialApp(
        title: 'Wavelength Clone',
        theme: ThemeData(useMaterial3: true),
        // Use a simple, direct initial route like the old working version
        initialRoute: HomeScreen.routeName, 
        routes: {
          // Define all routes here for clarity
          HomeScreen.routeName: (_) => const HomeScreen(),
          SettingsScreen.routeName: (_) => const SettingsScreen(),
        },
        // Use onGenerateRoute for routes that need to pass arguments (like roomId)
        onGenerateRoute: (settings) {
          final args = settings.arguments;

          // Guard against invalid arguments for routes that need them
          if (settings.name != HomeScreen.routeName && settings.name != SettingsScreen.routeName) {
            if (args is! String || args.isEmpty) {
              // If roomId is missing for a screen that needs it, default to HomeScreen
              return MaterialPageRoute(builder: (_) => const HomeScreen());
            }
          }

          switch (settings.name) {
            case LobbyScreen.routeName:
              return MaterialPageRoute(builder: (_) => LobbyScreen(roomId: args as String));
            case ReadyScreen.routeName:
              return MaterialPageRoute(builder: (_) => ReadyScreen(roomId: args as String));
            case SetupRoundScreen.routeName:
              return MaterialPageRoute(builder: (_) => SetupRoundScreen(roomId: args as String));
            case WaitingClueScreen.routeName:
              return MaterialPageRoute(builder: (_) => WaitingClueScreen(roomId: args as String));
            case GuessRoundScreen.routeName:
              return MaterialPageRoute(builder: (_) => GuessRoundScreen(roomId: args as String));
            case ResultScreen.routeName:
              return MaterialPageRoute(builder: (_) => ResultScreen(roomId: args as String));
            case ScoreboardScreen.routeName:
              return MaterialPageRoute(builder: (_) => ScoreboardScreen(roomId: args as String));
            case MatchSummaryScreen.routeName:
              return MaterialPageRoute(builder: (_) => MatchSummaryScreen(roomId: args as String));
            default:
              // If route is not found, go to home
              return MaterialPageRoute(builder: (_) => const HomeScreen());
          }
        },
      ),
    );
  }
}