// lib/screens/result_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart'; // Import for DocumentSnapshot
import 'package:rxdart/rxdart.dart'; // Import rxdart for stream combination
import 'package:wavelength_clone_fresh/screens/dialog_helpers.dart';

import '../services/firebase_service.dart';
import '../models/player_status.dart';
import '../models/round.dart'; // Import Round model AND Effect enum
import 'home_screen.dart'; // To navigate back to home
import 'scoreboard_screen.dart'; // Import for navigating to scoreboard
import 'dice_roll_screen.dart'; // Import for potential direct navigation
import 'setup_round_screen.dart'; // Import for potential direct navigation
import 'match_summary_screen.dart'; // Import for potential direct navigation


class ResultScreen extends StatefulWidget {
  static const routeName = '/result';
  final String roomId;
  const ResultScreen({Key? key, required this.roomId}) : super(key: key);

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  bool _showingLastPlayerDialog = false;

  @override
  void initState() {
    super.initState();
    _setupPlayerListeners();
  }

  void _setupPlayerListeners() {
    // Listen for player departures to show toast messages
    context.read<FirebaseService>().listenToLastPlayerStatus(widget.roomId).listen((status) async {
      final isLastPlayer = status['isLastPlayer'] as bool;

      if (isLastPlayer && !_showingLastPlayerDialog && mounted) {
        setState(() { _showingLastPlayerDialog = true; });

        // Use the global dialog function
        await showLastPlayerDialog(context, status['currentUserDisplayName'], widget.roomId);
        
        // After the dialog is closed, we can reset the flag
        if (mounted) {
          setState(() { _showingLastPlayerDialog = false; });
        }
      }
    });

    // Listen for last player standing scenario
    context.read<FirebaseService>().listenToLastPlayerStatus(widget.roomId).listen((status) async {
      final onlinePlayerCount = status['onlinePlayerCount'] as int;
      final isLastPlayer = status['isLastPlayer'] as bool;
      final currentUserDisplayName = status['currentUserDisplayName'] as String;
      final roomId = widget.roomId;

      // Get room data to check if current user is creator and it's the very beginning
      final roomSnap = await context.read<FirebaseService>().roomDocRef(roomId).get();
      final roomData = roomSnap.data();
      final isCreator = roomData?['creator'] == context.read<FirebaseService>().currentUserUid;
      final currentRoundNumber = roomData?['currentRoundNumber'] as int? ?? 0;

      // Suppress dialog if creator and it's the very first round (currentRoundNumber is 0 or 1)
      final isInitialRoomCreation = isCreator && currentRoundNumber <= 1;

      if (isLastPlayer && onlinePlayerCount == 1 && !_showingLastPlayerDialog && mounted && !isInitialRoomCreation) {
        setState(() {
          _showingLastPlayerDialog = true;
        });
      } else if (!isLastPlayer && onlinePlayerCount > 1 && _showingLastPlayerDialog) {
        // If more players join, dismiss the dialog if it's showing
        if (Navigator.of(context).canPop()) {
          Navigator.of(context).pop();
        }
        setState(() {
          _showingLastPlayerDialog = false;
        });
      }
    });
  }

  

  

  // Helper to get a string representation of the effect
  String _getEffectDescription(Effect? effect) {
    if (effect == null || effect == Effect.none) {
      return '';
    }
    switch (effect) {
      case Effect.doubleScore: return 'Double Score!';
      case Effect.halfScore: return 'Half Score!';
      case Effect.token: return 'Navigator gets a Token!';
      case Effect.reverseSlider: return 'Reverse Slider!';
      case Effect.noClue: return 'No Clue!';
      case Effect.blindGuess: return 'Blind Guess!';
      default: return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Round Results'),
        actions: [
          IconButton(
            icon: const Icon(Icons.exit_to_app),
            onPressed: () => showExitConfirmationDialog(context, widget.roomId),
          ),
        ],
      ),
      body: StreamBuilder<List<dynamic>>( // Combine latest of Round and Room data
        stream: Rx.combineLatest2(
          fb.listenCurrentRound(widget.roomId),
          fb.roomDocRef(widget.roomId).snapshots(),
          (Round currentRound, DocumentSnapshot<Map<String, dynamic>> roomSnap) {
            final roomData = roomSnap.data()!;
            final currentRoundNumber = roomData['currentRoundNumber'] as int? ?? 0;
            final roomStatus = roomData['status'] as String? ?? ''; // Get current room status
            final diceRollEnabled = roomData['diceRollEnabled'] as bool? ?? false; // Get diceRollEnabled
            return [currentRound, currentRoundNumber, roomData['creator'], roomStatus, diceRollEnabled]; // Also pass creatorUid, roomStatus, diceRollEnabled
          },
        ),
        builder: (ctx, snap) {
          if (!snap.hasData || snap.data![0] == null || snap.data![1] == null || snap.data![2] == null || snap.data![3] == null || snap.data![4] == null) {
            return const Center(child: CircularProgressIndicator());
          }
          final currentRound = snap.data![0] as Round;
          final currentRoundNumber = snap.data![1] as int;
          final hostUid = snap.data![2] as String;
          final currentRoomStatus = snap.data![3] as String;
          final diceRollEnabled = snap.data![4] as bool;


          // --- FALLBACK NAVIGATION FOR SEEKERS (if RoomNavigator in main.dart misses a status change) ---
          // This block should ideally not be hit if main.dart's RoomNavigator is perfect.
          // It's a safety net to force navigation if the room status has already changed
          // but this specific screen hasn't been replaced.
          if (currentRoomStatus != 'round_end' && currentRoomStatus != 'match_end' && mounted) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              String? nextRoute;
              if (currentRoomStatus == 'dice_roll') {
                nextRoute = DiceRollScreen.routeName;
              } else if (currentRoomStatus == 'clue_submission') {
                nextRoute = SetupRoundScreen.routeName;
              } else if (currentRoomStatus == 'guessing') {
                // Should ideally not happen from result screen to guessing directly, but as fallback
                nextRoute = 'guess_round_screen'; // Use actual route name
              }

              if (currentRoomStatus == 'match_end') {
                nextRoute = MatchSummaryScreen.routeName;
              }


              if (nextRoute != null && ModalRoute.of(context)?.settings.name != nextRoute) {
                print('DEBUG: Fallback navigation from ResultScreen. Status: $currentRoomStatus. Navigating to: $nextRoute');
                Navigator.pushReplacementNamed(context, nextRoute, arguments: widget.roomId);
              }
            });
            return const SizedBox(); // Return empty box while navigating
          }
          // --- END FALLBACK NAVIGATION ---


          // Ensure basic data for results is available
          if (currentRound.secretPosition == null || currentRound.groupGuessPosition == null) {
            return const Center(child: CircularProgressIndicator());
          }

          final secret = currentRound.secretPosition!;
          final guess = currentRound.groupGuessPosition!;
          final score = currentRound.score ?? 0; // Use score from Firestore
          final effect = currentRound.effect; // Get the effect

          String effectDescription = _getEffectDescription(effect);

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Round $currentRoundNumber Results',
                  style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 16),
                if (effect != null && effect != Effect.none)
                  Text(
                    'Effect: $effectDescription',
                    style: TextStyle(fontSize: 18, fontStyle: FontStyle.italic, color: Colors.deepOrange.shade700, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                const SizedBox(height: 24),
                Text('Secret was: $secret',
                    style: const TextStyle(fontSize: 24)),
                Text('Group Guess: $guess',
                    style: const TextStyle(fontSize: 24)),
                const SizedBox(height: 16),
                Text('Score: $score points',
                    style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.blueAccent)),
                const SizedBox(height: 32),
                const Spacer(),
                const Text( // Added const
                  'Confirm readiness for the next round below.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontStyle: FontStyle.italic, color: Color.fromARGB(255, 100, 100, 100)),
                ),
                const Spacer(),
              ],
            ),
          );
        },
      ),
      bottomNavigationBar: NextRoundControls(roomId: widget.roomId),
    );
  }
}

class NextRoundControls extends StatefulWidget {
  final String roomId;
  const NextRoundControls({Key? key, required this.roomId})
      : super(key: key);

  @override
  State<NextRoundControls> createState() => _NextRoundControlsState();
}

class _NextRoundControlsState extends State<NextRoundControls> {
  // Use a local flag to prevent multiple rapid taps on the host button
  bool _hostActionInProgress = false;

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();
    final roomId = widget.roomId;
    final myUid = fb.currentUserUid;

    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: fb.roomDocRef(roomId).snapshots(),
      builder: (ctx, roomSnap) {
        if (!roomSnap.hasData || roomSnap.data?.data() == null) {
          return const SizedBox(
            height: 80,
            child: Center(child: CircularProgressIndicator()),
          );
        }
        final roomData = roomSnap.requireData.data()!;
        final hostUid = roomData['creator'] as String? ?? '';
        final currentRoundNumber = roomData['currentRoundNumber'] as int? ?? 0;
        final isMatchEnd = currentRoundNumber >= 5;
        final currentRoomStatus = roomData['status'] as String? ?? '';
        final diceRollEnabled = roomData['diceRollEnabled'] as bool? ?? false;


        // Stream for players' readiness
        return StreamBuilder<List<PlayerStatus>>(
          stream: fb.listenToReady(roomId),
          builder: (ctx, playersSnap) {
            if (!playersSnap.hasData) {
              return const SizedBox(
                height: 80,
                child: Center(child: CircularProgressIndicator()),
              );
            }
            final players = playersSnap.requireData;
            final allReady = players.every((p) => p.ready);
            final me = players.firstWhere(
              (p) => p.uid == myUid,
              orElse: () => PlayerStatus(
                uid: myUid,
                displayName: 'You',
                ready: false,
                online: true,
                guessReady: false,
              ),
            );

            // Determine if the individual "I'm Ready" button should be enabled
            final bool individualButtonEnabled = (currentRoomStatus == 'round_end' && !me.ready);

            return Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Individual "I'm Ready" toggle button for ALL players
                  ElevatedButton(
                    onPressed: individualButtonEnabled
                        ? () => fb.setReady(roomId, !me.ready)
                        : null, // Disable if not enabled
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: Text(
                      me.ready
                          ? 'I\'m Ready (Waiting for others)'
                          : isMatchEnd
                              ? 'I\'m Ready for Summary'
                              : 'I\'m Ready for Next Round',
                      style: const TextStyle(fontSize: 18),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Host-only "All Ready! Go to Next Round" button
                  if (myUid == hostUid)
                    ElevatedButton(
                      onPressed: allReady && !_hostActionInProgress && currentRoomStatus == 'round_end'
                          ? () async {
                              setState(() {
                                _hostActionInProgress = true; // Prevent multiple taps
                              });
                              print('DEBUG: HOST in NextRoundControls. Room: $roomId. All ready. Triggering incrementRoundAndReset. Status: $currentRoomStatus');
                              await fb.incrementRoundAndReset(roomId);
                              // Reset flag after action, although navigation will often dispose this widget
                              if (mounted) {
                                setState(() {
                                  _hostActionInProgress = false;
                                });
                              }
                            }
                          : null, // Disabled if not all ready or action in progress
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: Text(
                        allReady
                            ? (isMatchEnd ? 'All Ready — Show Match Summary' : 'All Ready — Next Round')
                            : 'Waiting for players to be ready...',
                        style: const TextStyle(fontSize: 18),
                      ),
                    ),

                  // Display waiting message for non-host
                  if (myUid != hostUid && currentRoomStatus == 'round_end' && !allReady)
                    const Text(
                      'Waiting for all players to confirm readiness...',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontStyle: FontStyle.italic, color: Colors.grey),
                    ),
                  // Display message when all are ready (for non-host) and current status is 'round_end'
                  if (myUid != hostUid && allReady && currentRoomStatus == 'round_end')
                    const Text(
                      'Waiting for host to start next round...',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontStyle: FontStyle.italic, color: Colors.grey),
                    ),
                  // General proceeding message visible to all (including host) once status changes
                  // This message will appear as soon as roomStatus changes away from 'round_end'
                  if (currentRoomStatus == 'clue_submission' || currentRoomStatus == 'dice_roll' || currentRoomStatus == 'match_end')
                    Text(
                      isMatchEnd
                          ? 'Proceeding to Match Summary...'
                          : 'Proceeding to Next Round...',
                      style: TextStyle(fontStyle: FontStyle.italic, color: Colors.green[700]),
                      textAlign: TextAlign.center,
                    ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}
