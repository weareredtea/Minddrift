// lib/screens/ready_screen.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'package:wavelength_clone_fresh/screens/dialog_helpers.dart';
import 'package:wavelength_clone_fresh/screens/dice_roll_screen.dart';
import 'package:wavelength_clone_fresh/screens/setup_round_screen.dart';
import '../screens/dialog_helpers.dart';
import '../services/firebase_service.dart';

class ReadyScreen extends StatefulWidget {
  static const routeName = '/ready';
  final String roomId;
  const ReadyScreen({Key? key, required this.roomId}) : super(key: key);

  @override
  State<ReadyScreen> createState() => _ReadyScreenState();
}

class _ReadyScreenState extends State<ReadyScreen> {
  // Flag to prevent the host from double-tapping the start button
  bool _isStartingRound = false;

  @override
  void initState() {
    super.initState();
    WakelockPlus.enable();
  }

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();
    final roomId = widget.roomId;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Get Ready'),
        actions: [
          IconButton(
            icon: const Icon(Icons.exit_to_app),
            onPressed: () => showExitConfirmationDialog(context, roomId),
          ),
        ],
      ),
      // --- THIS IS THE NEW LISTENER ---
      // This StreamBuilder now listens to the room's status. When the status changes,
      // it will trigger the navigation to the next screen.
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: fb.roomDocRef(roomId).snapshots(),
        builder: (context, roomSnap) {
          if (!roomSnap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final roomStatus = roomSnap.data?.data()?['status'] as String? ?? 'lobby';

          // --- NAVIGATION LOGIC ---
          // If the status changes to one of the in-game states, navigate away.
          if (roomStatus == 'dice_roll' || roomStatus == 'clue_submission') {
            // Use a post-frame callback to ensure navigation happens safely after build.
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (mounted) {
                // Determine where to go based on the status
                String routeName = roomStatus == 'dice_roll'
                    ? DiceRollScreen.routeName
                    : SetupRoundScreen.routeName;
                
                Navigator.pushReplacementNamed(context, routeName, arguments: roomId);
              }
            });
            // Show a loading indicator during the very brief transition period
            return const Center(child: CircularProgressIndicator());
          }

          // If the status is still 'lobby', show the normal Ready Screen UI.
          // We use the new, clean ViewModel for the UI logic.
          return StreamBuilder<ReadyScreenViewModel>(
            stream: fb.listenToReadyScreenViewModel(roomId),
            builder: (ctx, vmSnap) {
              if (!vmSnap.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              final viewModel = vmSnap.data!;
              final players = viewModel.players;
              final me = viewModel.me;

              return Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text('Room Code: $roomId',
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 16),

                    // Player list
                    Expanded(
                      child: ListView.builder(
                        itemCount: players.length,
                        itemBuilder: (context, index) {
                          players.sort((a, b) => a.displayName.compareTo(b.displayName));
                          final p = players[index];
                          return ListTile(
                            leading: Icon(
                              p.ready
                                  ? Icons.check_circle
                                  : Icons.radio_button_unchecked,
                              color: p.ready ? Colors.green : null,
                            ),
                            title: Text(p.displayName),
                            trailing: Icon(
                              p.online ? Icons.circle : Icons.circle_outlined,
                              size: 12,
                              color: p.online ? Colors.green : Colors.red,
                            ),
                          );
                        },
                      ),
                    ),

                    const SizedBox(height: 12),

                    // "I'm Ready" button
                    if (me != null)
                      ElevatedButton(
                        onPressed: () => fb.setReady(roomId, !me.ready),
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                        child: Text(
                          me.ready ? 'Cancel Ready' : 'I\'m Ready',
                          style: const TextStyle(fontSize: 18),
                        ),
                      ),
                    const SizedBox(height: 16),

                    // Host-only button
                    if (viewModel.isHost)
                      ElevatedButton(
                        onPressed:
                            viewModel.allPlayersReady && !_isStartingRound
                                ? () {
                                    print('DEBUG: Host button pressed. Calling startRound...');
                                    setState(() {
                                      _isStartingRound = true;
                                    });
                                    fb.startRound(roomId);
                                  }
                                : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: viewModel.allPlayersReady
                              ? Colors.green
                              : Colors.grey,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                              vertical: 16, horizontal: 24),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                        child: Text(
                          viewModel.allPlayersReady
                              ? 'All Ready — Start Round'
                              : 'Waiting For Players...',
                          style: const TextStyle(fontSize: 18),
                        ),
                      ),

                    // Waiting message for non-hosts
                    if (!viewModel.isHost)
                      Text(
                        viewModel.allPlayersReady
                            ? 'Waiting for the host to start the game...'
                            : 'Waiting for all players to get ready...',
                        style: const TextStyle(
                            fontStyle: FontStyle.italic, color: Colors.grey),
                      ),

                    const SizedBox(height: 16),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}