// lib/screens/ready_screen.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/firebase_service.dart';
import '../models/player_status.dart';
import 'setup_round_screen.dart';

class ReadyScreen extends StatefulWidget {
  static const routeName = '/ready';
  final String roomId;
  const ReadyScreen({Key? key, required this.roomId}) : super(key: key);

  @override
  State<ReadyScreen> createState() => _ReadyScreenState();
}

class _ReadyScreenState extends State<ReadyScreen> {
  @override
  void initState() {
    super.initState();
    // Listen for the host kicking off startRound(...)
    final fb = context.read<FirebaseService>();
    fb.listenRoundStarted(widget.roomId).listen((started) {
      if (started) {
        Navigator.pushReplacementNamed(
          context,
          SetupRoundScreen.routeName,
          arguments: widget.roomId,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final fb     = context.read<FirebaseService>();
    final roomId = widget.roomId;
    final myUid  = fb.currentUserUid;

    return Scaffold(
      appBar: AppBar(title: const Text('Get Ready')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text('Room Code: $roomId',
                style:
                    const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),

            // 1) List of players + their ready-/online icons
            Expanded(
              child: StreamBuilder<List<PlayerStatus>>(
                stream: fb.listenToReady(roomId),
                builder: (ctx, snap) {
                  if (!snap.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  final players = snap.requireData;
                  return ListView(
                    children: players.map((p) {
                      return ListTile(
                        leading: Icon(
                          p.ready
                              ? Icons.check_circle
                              : Icons.radio_button_unchecked,
                          color: p.ready ? Colors.green : null,
                        ),
                        title: Text(p.displayName),
                        trailing: Icon(
                          p.online ? Icons.circle : Icons.circle_outlined,
                          size: 12,
                          color: p.online ? Colors.green : Colors.red,
                        ),
                      );
                    }).toList(),
                  );
                },
              ),
            ),

            const SizedBox(height: 12),

            // 2) My “I’m Ready” toggle button
            StreamBuilder<List<PlayerStatus>>(
              stream: fb.listenToReady(roomId),
              builder: (ctx, snap) {
                if (!snap.hasData) return const SizedBox();
                final me = snap.requireData.firstWhere(
                  (p) => p.uid == myUid,
                  orElse: () => PlayerStatus(
                    uid: myUid,
                    displayName: 'You',
                    ready: false,
                    online: true,
                  ),
                );
                return ElevatedButton(
                  onPressed: () =>
                      fb.setReady(roomId, !me.ready), // public API
                  child: Text(me.ready ? 'Cancel Ready' : 'I\'m Ready'),
                );
              },
            ),

            const SizedBox(height: 16),

            // 3) Host-only “All Ready — Start Round” button
            StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
              stream: FirebaseFirestore.instance
                  .collection('rooms')
                  .doc(roomId)
                  .snapshots(),
              builder: (ctx, roomSnap) {
                if (!roomSnap.hasData) return const SizedBox();
                final roomData = roomSnap.requireData.data() ?? {};
                final hostUid = roomData['creator'] as String? ?? '';
                if (hostUid != myUid) return const SizedBox();

                // Only show once everyone is ready
                return StreamBuilder<List<PlayerStatus>>(
                  stream: fb.listenToReady(roomId),
                  builder: (ctx2, snap2) {
                    if (!snap2.hasData) return const SizedBox();
                    final allReady =
                        snap2.requireData.every((p) => p.ready);
                    return ElevatedButton(
                      onPressed: allReady
                          ? () => fb.startRound(roomId)
                          : null,
                      child: const Text('All Ready — Start Round'),
                    );
                  },
                );
              },
            ),

            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
