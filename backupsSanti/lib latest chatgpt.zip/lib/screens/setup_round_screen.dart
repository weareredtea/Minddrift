import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/firebase_service.dart';
import '../widgets/slider_dial.dart';
import 'guess_round_screen.dart';

class SetupRoundScreen extends StatefulWidget {
  static const routeName = '/setup';
  final String roomId;
  const SetupRoundScreen({Key? key, required this.roomId}) : super(key: key);

  @override
  State<SetupRoundScreen> createState() => _SetupRoundScreenState();
}

class _SetupRoundScreenState extends State<SetupRoundScreen> {
  late Future<void> _initFuture;
  String _clue = '';
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    _initFuture = _initializeRound();
  }

  Future<void> _initializeRound() async {
    final fb = context.read<FirebaseService>();
  }

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();
    final roomId = widget.roomId;

    return Scaffold(
      appBar: AppBar(title: const Text('Navigator: Set Your Clue')),
      body: FutureBuilder<void>(
        future: _initFuture,
        builder: (ctx, initSnap) {
          if (initSnap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          // Now that roles & position are set, stream the round doc
          return StreamBuilder<Map<String, dynamic>>(
            stream: fb
                .roundDocRef(roomId)
                .snapshots()
                .map((snap) => snap.data() ?? {}),
            builder: (ctx, snap) {
              if (!snap.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              final data       = snap.requireData;
              final secretPos  =
                  (data['secretPosition'] as num?)?.toDouble() ?? 50.0;

              return Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      '🔒 Secret position is set — enter your clue',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 16),
                    ),
                    const SizedBox(height: 16),

                    // Read-only slider showing the secret position
                    SliderDial(
                      value: secretPos,
                      divisions: 100,
                      onChanged: (_) {}, // no-op
                    ),
                    const SizedBox(height: 16),

                    // Clue input
                    TextField(
                      decoration:
                          const InputDecoration(labelText: 'One-word clue'),
                      onChanged: (v) => setState(() => _clue = v.trim()),
                    ),

                    const Spacer(),

                    ElevatedButton(
                      onPressed: _clue.isEmpty || _submitting
                          ? null
                          : () async {
                              setState(() => _submitting = true);
                              await fb.submitClue(
                                  roomId, secretPos.round(), _clue);
                              setState(() => _submitting = false);
                              Navigator.pushReplacementNamed(
                                context,
                                GuessRoundScreen.routeName,
                                arguments: roomId,
                              );
                            },
                      child: _submitting
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child:
                                  CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Text('Lock In Clue'),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}
