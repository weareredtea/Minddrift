// lib/screens/result_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/firebase_service.dart';
import '../models/player_status.dart';

class ResultScreen extends StatelessWidget {
  static const routeName = '/result';
  final String roomId;
  const ResultScreen({Key? key, required this.roomId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();

    return Scaffold(
      appBar: AppBar(title: const Text('Round Results')),
      body: StreamBuilder<Map<String, dynamic>>(
        stream: fb
            .roundDocRef(roomId)
            .snapshots()
            .map((snap) => snap.data() ?? {}),
        builder: (ctx, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final data     = snap.requireData;
          final secret   = (data['secretPosition'] as num?)?.toInt() ?? 0;
          final guess    = (data['groupGuessPosition'] as num?)?.toInt() ?? 0;
          final distance = (secret - guess).abs();
          final score    = distance <= 5
              ? 6
              : distance <= 10
                  ? 3
                  : distance <= 20
                      ? 1
                      : 0;

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Text('Secret was: $secret',
                    style: const TextStyle(fontSize: 20)),
                Text('Your guess: $guess',
                    style: const TextStyle(fontSize: 20)),
                const SizedBox(height: 16),
                Text('Score: $score',
                    style: const TextStyle(fontSize: 24)),
              ],
            ),
          );
        },
      ),
      bottomNavigationBar: NextRoundControls(roomId: roomId),
    );
  }
}

class NextRoundControls extends StatefulWidget {
  final String roomId;
  const NextRoundControls({Key? key, required this.roomId})
      : super(key: key);

  @override
  State<NextRoundControls> createState() => _NextRoundControlsState();
}

class _NextRoundControlsState extends State<NextRoundControls> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final fb     = context.read<FirebaseService>();
    final roomId = widget.roomId;

    return StreamBuilder<List<PlayerStatus>>(
      stream: fb.listenToReady(roomId),
      builder: (ctx, snap) {
        if (!snap.hasData) {
          return const SizedBox(
            height: 80,
            child: Center(child: CircularProgressIndicator()),
          );
        }
        final players = snap.requireData;
        final allReady = players.every((p) => p.ready);

        return Padding(
          padding: const EdgeInsets.all(16),
          child: ElevatedButton(
            onPressed: allReady && !_pressed
                ? () {
                    setState(() => _pressed = true);
                    fb.incrementRoundNumber(roomId);
                  }
                : null,
            child: const Text('All Ready — Next Round'),
          ),
        );
      },
    );
  }
}
