// lib/models/round.dart

import 'package:cloud_firestore/cloud_firestore.dart';

enum Effect {
  emoji, voice, short, reroll, doubleScore, halfScore, none, token
}
enum Role { Navigator, Seeker, Saboteur }

class Round {
  final String? clue;
  final int? secretPosition;
  final Map<String,int>? guesses;
  final Map<String,Role>? roles;
  final Effect? effect;
  final String? categoryLeft;
  final String? categoryRight;
  final DateTime? effectRolledAt;

  Round({
    this.clue,
    this.secretPosition,
    this.guesses,
    this.roles,
    this.effect,
    this.categoryLeft,
    this.categoryRight,
    this.effectRolledAt,
  });

  /// Public converter: parse Effect from its lowercase name.
  static Effect effectFromString(String? s) {
    if (s == null) return Effect.none;
    return Effect.values.firstWhere(
      (e) => e.toString().split('.').last.toLowerCase() == s.toLowerCase(),
      orElse: () => Effect.none,
    );
  }

  factory Round.fromMap(Map<String, dynamic> m) {
    return Round(
      clue: m['clue'] as String?,
      secretPosition: m['secretPosition'] as int?,
      guesses: (m['guesses'] as Map?)?.cast<String,int>(),
      roles: (m['roles'] as Map?)?.cast<String,String>().map((k,v) {
        final role = Role.values.firstWhere(
          (e) => e.toString().split('.').last.toLowerCase() == v.toLowerCase()
        );
        return MapEntry(k, role);
      }),
      effect: effectFromString(m['effect'] as String?),
      categoryLeft: m['categoryLeft'] as String?,
      categoryRight: m['categoryRight'] as String?,
      effectRolledAt: (m['effectRolledAt'] as Timestamp?)?.toDate(),
    );
  }
}
