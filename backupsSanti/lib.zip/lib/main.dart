// lib/main.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';

import 'services/firebase_service.dart';
import 'firebase_options.dart';

import 'screens/home_screen.dart';
import 'screens/lobby_screen.dart';
import 'screens/ready_screen.dart';
import 'screens/dice_overlay_screen.dart';
import 'screens/setup_round_screen.dart';
import 'screens/waiting_clue_screen.dart';
import 'screens/guess_round_screen.dart';
import 'screens/result_screen.dart';
import 'screens/match_summary_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return Provider(
      create: (_) => FirebaseService(),
      child: MaterialApp(
        title: 'Wavelength Clone',
        theme: ThemeData.light(),
        darkTheme: ThemeData.dark(),
        initialRoute: HomeScreen.routeName,
        routes: {
          HomeScreen.routeName: (_) => const HomeScreen(),
          LobbyScreen.routeName: (_) => const LobbyScreen(roomId: '',),

          ReadyScreen.routeName: (ctx) {
            final roomId = ModalRoute.of(ctx)!.settings.arguments as String;
            return ReadyScreen(roomId: roomId);
          },
          DiceOverlayScreen.routeName: (ctx) {
            final roomId = ModalRoute.of(ctx)!.settings.arguments as String;
            return DiceOverlayScreen(roomId: roomId);
          },
          SetupRoundScreen.routeName: (ctx) {
            final roomId = ModalRoute.of(ctx)!.settings.arguments as String;
            return SetupRoundScreen(roomId: roomId);
          },
          WaitingClueScreen.routeName: (ctx) {
            final roomId = ModalRoute.of(ctx)!.settings.arguments as String;
            return WaitingClueScreen(roomId: roomId);
          },
          GuessRoundScreen.routeName: (ctx) {
            final roomId = ModalRoute.of(ctx)!.settings.arguments as String;
            return GuessRoundScreen(roomId: roomId);
          },
          ResultScreen.routeName: (ctx) {
            final roomId = ModalRoute.of(ctx)!.settings.arguments as String;
            return ResultScreen(roomId: roomId);
          },
          MatchSummaryScreen.routeName: (ctx) {
            final roomId = ModalRoute.of(ctx)!.settings.arguments as String;
            return MatchSummaryScreen(roomId: roomId);
          },
        },
      ),
    );
  }
}
