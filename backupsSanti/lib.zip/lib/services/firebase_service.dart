// lib/services/firebase_service.dart

import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:wavelength_clone_fresh/models/round_history_entry.dart';

import '../models/player_status.dart';
import '../models/round.dart';       // for Effect, Role, Round.fromMap
import '../pigeon/pigeon.dart';      // for PigeonUserDetails

class FirebaseService {
  final FirebaseAuth     _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db   = FirebaseFirestore.instance;
  final Random            _rnd  = Random();
  

  static const String _chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  String get currentUserUid => _auth.currentUser!.uid;
  String _randomCode(int n) =>
      List.generate(n, (_) => _chars[_rnd.nextInt(_chars.length)]).join();


 /// Sign in anonymously and return the actual Firebase User.
Future<User> signInAnonymously() async {
  final cred = await _auth.signInAnonymously();
  return cred.user!;

}

Future<List<PigeonUserDetails>> fetchPlayers(String roomId) async {
  final col = await _db
      .collection('rooms').doc(roomId)
      .collection('players')
      .get();
  return col.docs.map((doc) {
    final data = doc.data();
    return PigeonUserDetails(
      uid: doc.id,
      displayName: data['displayName'] as String? ?? 'Anonymous',
    );
  }).toList();
}



  // ─── Room & Player Management ───────────────────────────────────────────

  Future<bool> roomExists(String roomId) async {
    return (await _db.collection('rooms').doc(roomId).get()).exists;
  }
 

  Future<String> createRoom({
    bool saboteurEnabled = false,
    bool teamBattleEnabled = false,
  }) async {
    final user = await signInAnonymously();
    final uid  = user.uid;

    late String roomId;
    do {
      roomId = _randomCode(4);
    } while ((await _db.collection('rooms').doc(roomId).get()).exists);

    await _db.collection('rooms').doc(roomId).set({
      'creator':           user.uid,
      'createdAt':         FieldValue.serverTimestamp(),
      'saboteurEnabled':   saboteurEnabled,
      'teamBattleEnabled': teamBattleEnabled,
      'roundNumber':       1,
    });

    await joinRoom(roomId);
    await seedPowerUps(roomId);
    await seedCategories(roomId);
    return roomId;
  }

  Future<void> joinRoom(String roomId) async {
    final user = await signInAnonymously();
    await _db
        .collection('rooms').doc(roomId)
        .collection('players').doc(user.uid)
        .set({
      'displayName':  user.uid,
      'joinedAt':     FieldValue.serverTimestamp(),
      'ready':        false,
      'guessReady':   false,
      'online':       true,
      'lastSeen':     FieldValue.serverTimestamp(),
      'usedEffects':  <String>[],
      'tokens':       0,
      'hand':         <String>[],
    });
  }

  // Presence
  Future<void> setOnline(String roomId) => _db
    .collection('rooms').doc(roomId)
    .collection('players').doc(currentUserUid)
    .update({'online': true, 'lastSeen': FieldValue.serverTimestamp()});

  Future<void> setOffline(String roomId) => _db
    .collection('rooms').doc(roomId)
    .collection('players').doc(currentUserUid)
    .update({'online': false});

  // ─── Power-Ups & Categories ─────────────────────────────────────────────

  Future<void> seedPowerUps(String roomId) async {
    final ups = [
      {'id':'narrow','name':'Narrow Range','description':'Halves the slider range','type':'NARROW'},
      {'id':'swap','  name':'Swap Endpoints','description':'Flip dial ends','type':'SWAP'},
      {'id':'double','name':'Double Clue','description':'Two-word clue','type':'DOUBLE'},
    ];
    final col = _db.collection('rooms').doc(roomId).collection('powerUps');
    for (var pu in ups) {
      await col.doc(pu['id']!).set(pu);
    }
  }

  Future<void> seedCategories(String roomId) async {
    final cats = <Map<String,String>>[
      {'id':'hot_cold','left':'HOT','right':'COLD'},
      {'id':'calm_noisy','left':'CALM','right':'NOISY'},
      {'id':'soft_rough','left':'SOFT','right':'ROUGH'},
      // …add your other 27 here…
    ];
    final col = _db.collection('rooms').doc(roomId).collection('categories');
    for (var c in cats) {
      await col.doc(c['id']!).set(c);
    }
  }

  // ─── Rounds / Gameplay ─────────────────────────────────────────────────

  DocumentReference<Map<String, dynamic>> roundDocRef(String roomId) =>
      _db.collection('rooms').doc(roomId)
         .collection('rounds').doc('current');

  Future<void> assignRoles(String roomId) async {
    final roomSnap = await _db.collection('rooms').doc(roomId).get();
    final sabEnabled = roomSnap.data()?['saboteurEnabled'] as bool? ?? false;

    final playersSnap = await _db
        .collection('rooms').doc(roomId)
        .collection('players').get();
    final uids = playersSnap.docs.map((d) => d.id).toList();
    if (uids.isEmpty) return;
    uids.shuffle();

    final rolesMap = <String,String>{};
    rolesMap[uids[0]] = 'Navigator';
    var idx = 1;
    if (sabEnabled && uids.length > 1) {
      rolesMap[uids[1]] = 'Saboteur';
      idx = 2;
    }
    for (var i = idx; i < uids.length; i++) {
      rolesMap[uids[i]] = 'Seeker';
    }

    await roundDocRef(roomId).set({'roles': rolesMap}, SetOptions(merge: true));
  }

  Future<Map<String, String>> fetchRoles(String roomId) async {
    final doc = await roundDocRef(roomId).get();
    final data = doc.data()?['roles'] as Map?;
    if (data == null) return {};
    return Map<String,String>.from(data);
  }

  Future<void> assignRandomPosition(String roomId) async {
    final pos = _rnd.nextInt(101);
    await roundDocRef(roomId)
      .set({'secretPosition': pos}, SetOptions(merge: true));
  }

  Future<Effect> assignRoundEffect(String roomId) async {
    // find navigator
    final roles = await fetchRoles(roomId);
    final navId = roles.entries
        .firstWhere((e) => e.value=='Navigator', orElse: ()=>MapEntry('',''))
        .key;
    // saboteur?
    final roomSnap = await _db.collection('rooms').doc(roomId).get();
    final sabEnabled = roomSnap.data()?['saboteurEnabled'] as bool? ?? false;
    final isSab = sabEnabled && roles[navId]=='Saboteur';

    // roll
    final effect = await _rollEffect(roomId, navId, isSab);
    final id = effect.toString().split('.').last;

    // persist
    await roundDocRef(roomId)
      .set({'effect': id, 'effectRolledAt': FieldValue.serverTimestamp()},
            SetOptions(merge: true));

    return effect;
  }

  Future<Effect> _rollEffect(String roomId, String navigatorUid, bool isSab) async {
    final pRef = _db.collection('rooms').doc(roomId)
        .collection('players').doc(navigatorUid);
    final pSnap = await pRef.get();
    final used = List<String>.from(pSnap.data()?['usedEffects'] as List? ?? []);

    final all = Effect.values;
    final filtered = all.where((e){
      if (e==Effect.token && isSab) return false;
      final id = e.toString().split('.').last;
      if ((e==Effect.reroll||e==Effect.doubleScore||e==Effect.halfScore)
          && used.contains(id)) return false;
      return true;
    }).toList();

    final pick = filtered[_rnd.nextInt(filtered.length)];
    final pid = pick.toString().split('.').last;
    if (pick==Effect.reroll||pick==Effect.doubleScore||pick==Effect.halfScore) {
      await pRef.update({'usedEffects': FieldValue.arrayUnion([pid])});
    }
    if (pick==Effect.token) {
      await pRef.update({'tokens': FieldValue.increment(1)});
    }
    return pick;
  }

  Future<void> assignCategory(String roomId) async {
    final snap = await _db.collection('rooms').doc(roomId)
        .collection('categories').get();
    final docs = snap.docs;
    if (docs.isEmpty) throw Exception('No categories');
    final pick = docs[_rnd.nextInt(docs.length)];
    final left = pick.data()['left'] as String;
    final right= pick.data()['right'] as String;
    await roundDocRef(roomId)
      .set({'categoryLeft': left, 'categoryRight': right},
            SetOptions(merge: true));
  }

  /// Navigator sets their clue.
  Future<void> submitClue(String roomId, int secretPos, String clue) =>
    roundDocRef(roomId)
      .set({'secretPosition': secretPos, 'clue': clue, 'creator': currentUserUid},
            SetOptions(merge: true));

  /// Seeker groups write.
  Future<void> submitGuess(String roomId, int guessPos) =>
    roundDocRef(roomId)
      .set({'guesses': {currentUserUid: guessPos}}, SetOptions(merge: true));

  // ─── Group Guess (solo) ─────────────────────────────────────────────

  Stream<double> listenGroupGuess(String roomId) =>
    roundDocRef(roomId).snapshots().map((s){
      final raw = (s.data()?['groupGuessPosition'] as num?)?.toDouble();
      return raw ?? 50.0;
    });

  Future<void> updateGroupGuess(String roomId, double v) =>
    roundDocRef(roomId)
      .set({'groupGuessPosition': v}, SetOptions(merge: true));

  // ─── Ready / GuessReady ───────────────────────────────────────────────

  Future<void> setReady(String roomId, bool ready) =>
    _db.collection('rooms').doc(roomId)
       .collection('players').doc(currentUserUid)
       .update({'ready': ready});

  Stream<List<PlayerStatus>> listenToReady(String roomId) =>
    _db.collection('rooms').doc(roomId)
       .collection('players').snapshots().map((snap){
         return snap.docs.map((d){
           final m = d.data();
           return PlayerStatus(
             uid: d.id,
             displayName: m['displayName'] as String? ?? 'Anonymous',
             ready: m['ready'] as bool? ?? false,
             online: m['online'] as bool? ?? false,
           );
         }).toList();
       });

  Future<void> setGuessReady(String roomId, bool r) =>
    _db.collection('rooms').doc(roomId)
       .collection('players').doc(currentUserUid)
       .update({'guessReady': r});

  Stream<List<PlayerStatus>> listenGuessReady(String roomId) =>
    _db.collection('rooms').doc(roomId)
       .collection('players').snapshots().asyncMap((snap) async {
         final roles = await fetchRoles(roomId);
         return snap.docs.where((d)=>roles[d.id]!='Navigator').map((d){
           final m = d.data();
           return PlayerStatus(
             uid: d.id,
             displayName: m['displayName'] as String? ?? 'Anonymous',
             ready: m['guessReady'] as bool? ?? false,
             online: m['online'] as bool? ?? false,
           );
         }).toList();
       });

  // ─── Round Number for auto-advance ───────────────────────────────────

  Future<void> incrementRoundNumber(String roomId) async {
    await _db.collection('rooms').doc(roomId)
      .update({'roundNumber': FieldValue.increment(1)});
  }

  Stream<int> listenRoundNumber(String roomId) =>
    _db.collection('rooms').doc(roomId)
       .snapshots().map((s) => (s.data()?['roundNumber'] as int?) ?? 1);

  // ─── History & Summary ────────────────────────────────────────────────

  Future<List<RoundHistoryEntry>> fetchHistory(String roomId) async {
    final snap = await _db.collection('rooms').doc(roomId)
      .collection('history').orderBy('roundNumber').get();
    return snap.docs.map((d)=>RoundHistoryEntry.fromMap(d.data())).toList();
  }

  // ─── Match Reset ──────────────────────────────────────────────────────

  Future<void> prepareNextRound(String roomId) async {
    final roomRef  = _db.collection('rooms').doc(roomId);
    final rdRef    = roundDocRef(roomId);

    await roomRef.update({'roundStarted': false});
    await rdRef.set({
      'clue':           null,
      'secretPosition': null,
      'effect':         null,
      'categoryLeft':   null,
      'categoryRight':  null,
      'guesses':        <String,dynamic>{},
      'groupGuessPosition': null,
    }, SetOptions(merge: false));

    final ps = await roomRef.collection('players').get();
    for (var d in ps.docs) {
      await d.reference.update({'ready': false, 'guessReady': false});
    }
  }
}
