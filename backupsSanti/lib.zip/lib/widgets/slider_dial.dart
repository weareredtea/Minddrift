// lib/widgets/slider_dial.dart

import 'package:flutter/material.dart';
import 'dart:math' as math;

class SliderDial extends StatelessWidget {
  final double value;
  final int divisions;
  final ValueChanged<double> onChanged;

  const SliderDial({
    Key? key,
    required this.value,
    required this.divisions,
    required this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Slider(
      value: value,
      divisions: divisions,
      min: 0,
      max: 100,
      label: value.round().toString(),
      onChanged: onChanged,
    );
  }
}
