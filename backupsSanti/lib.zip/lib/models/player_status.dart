// lib/models/player_status.dart

import 'package:cloud_firestore/cloud_firestore.dart';

class PlayerStatus {
  final String uid;
  final String displayName;
  final bool ready;
  final bool online;

  PlayerStatus({
    required this.uid,
    required this.displayName,
    required this.ready,
    required this.online,
  });

  factory PlayerStatus.fromSnapshot(
      DocumentSnapshot<Map<String, dynamic>> snap) {
    final m = snap.data()!;
    return PlayerStatus(
      uid: snap.id,
      displayName: m['displayName'] as String? ?? 'Anonymous',
      ready: m['ready'] as bool? ?? false,
      online: m['online'] as bool? ?? false,
    );
  }
}
