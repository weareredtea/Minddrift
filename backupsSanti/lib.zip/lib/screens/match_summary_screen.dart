// lib/screens/match_summary_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/firebase_service.dart';
import '../pigeon/pigeon.dart'; // for PigeonUserDetails

class MatchSummaryScreen extends StatelessWidget {
  static const routeName = '/summary';
  final String roomId;
  const MatchSummaryScreen({Key? key, required this.roomId})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();

    return Scaffold(
      appBar: AppBar(title: const Text('Match Summary')),
      body: FutureBuilder<List<PigeonUserDetails>>(
        future: fb.fetchPlayers(roomId),
        builder: (ctx, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          final players = snap.data ?? [];
          if (players.isEmpty) {
            return const Center(child: Text('No players found.'));
          }
          return ListView(
            padding: const EdgeInsets.all(16),
            children: players.map((u) {
              return ListTile(
                leading: const Icon(Icons.person),
                title: Text(u.displayName),
                subtitle: Text('UID: ${u.uid}'),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}
