// lib/screens/dice_overlay_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/firebase_service.dart';
import '../models/round.dart';
import 'setup_round_screen.dart';
import 'waiting_clue_screen.dart';

class DiceOverlayScreen extends StatefulWidget {
  static const routeName = '/dice';
  final String roomId;
  const DiceOverlayScreen({Key? key, required this.roomId}) : super(key: key);

  @override
  State<DiceOverlayScreen> createState() => _DiceOverlayScreenState();
}

class _DiceOverlayScreenState extends State<DiceOverlayScreen> {
  bool _didKickoff = false;

  @override
  Widget build(BuildContext context) {
    final fb    = context.read<FirebaseService>();
    final myUid = fb.currentUserUid;
    final roomId = widget.roomId;

    return Scaffold(
      backgroundColor: Colors.black87,
      body: StreamBuilder<Map<String, dynamic>>(
        stream: fb.roundDocRef(roomId).snapshots().map((s) => s.data() ?? {}),
        builder: (ctx, snap) {
          debugPrint(
              '🎲 [Overlay] state=${snap.connectionState} data=${snap.data}');
          if (snap.connectionState != ConnectionState.active) {
            return const Center(
                child: CircularProgressIndicator(color: Colors.white));
          }
          final data = snap.requireData;
          debugPrint('🎲 [Overlay] keys=${data.keys}');

          if (!_didKickoff) {
            _didKickoff = true;
            _kickoff(fb, myUid, roomId);
          }

          final eff = data['effect'] as String?;
          if (eff == null) {
            return const Center(
                child: CircularProgressIndicator(color: Colors.white));
          }

          final effect = Round.effectFromString(eff);
          return _buildEffect(effect, roomId);
        },
      ),
    );
  }

  void _kickoff(FirebaseService fb, String myUid, String roomId) async {
    debugPrint('🎲 [Overlay] kickoff');
    final roles = await fb.fetchRoles(roomId);
    if (roles[myUid] != Role.Navigator.toString().split('.').last) return;

    debugPrint('🎲 [Overlay] I am Navigator—rolling…');
    await fb.assignRoles(roomId);
    await fb.assignRandomPosition(roomId);
    final effect = await fb.assignRoundEffect(roomId);
    await fb.assignCategory(roomId);
    debugPrint('🎲 [Overlay] rolled $effect');
  }

  Widget _buildEffect(Effect effect, String roomId) {
    Timer(const Duration(seconds: 2), () {
      if (!mounted) return;
      final fb = context.read<FirebaseService>();
      fb.fetchRoles(roomId).then((roles) {
        final myRole = roles[fb.currentUserUid];
        final route = myRole == Role.Navigator.toString().split('.').last
            ? SetupRoundScreen.routeName
            : WaitingClueScreen.routeName;
        Navigator.pushReplacementNamed(context, route,
            arguments: roomId);
      });
    });

    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.casino, size: 64, color: Colors.white),
          const SizedBox(height: 16),
          Text('Effect: ${effect.toString().split('.').last}',
              style: const TextStyle(
                  fontSize: 32,
                  color: Colors.white,
                  fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
