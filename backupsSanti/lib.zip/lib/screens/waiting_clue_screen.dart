// lib/screens/waiting_clue_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/firebase_service.dart';
import '../widgets/slider_dial.dart';
import 'guess_round_screen.dart';

class WaitingClueScreen extends StatelessWidget {
  static const routeName = '/waiting';
  final String roomId;
  const WaitingClueScreen({Key? key, required this.roomId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();

    return Scaffold(
      appBar: AppBar(title: const Text('Waiting for Clue')),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: fb.roundDocRef(roomId).snapshots(),
        builder: (ctx, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final data = snap.data!.data()!;
          final clue = data['clue'] as String? ?? '';

          if (clue.isEmpty) {
            return const Center(child: Text('Navigator is thinking…'));
          }

          // Once clue appears, go to GuessRoundScreen
          WidgetsBinding.instance.addPostFrameCallback((_) {
            Navigator.pushReplacementNamed(
              context,
              GuessRoundScreen.routeName,
              arguments: roomId,
            );
          });
          return const SizedBox();
        },
      ),
    );
  }
}
