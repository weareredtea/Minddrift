// lib/screens/scoreboard_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:wavelength_clone_fresh/models/round_history_entry.dart';
import '../services/firebase_service.dart';
import '../models/round.dart';

class ScoreboardScreen extends StatelessWidget {
  static const routeName = '/scoreboard';
  final String roomId;
  const ScoreboardScreen({Key? key, required this.roomId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();

    return Scaffold(
      appBar: AppBar(title: const Text('Scoreboard')),
      body: FutureBuilder<List<RoundHistoryEntry>>(
        future: fb.fetchHistory(roomId),
        builder: (ctx, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const CircularProgressIndicator();
          }
          final history = snap.data ?? [];
          return ListView(
            children: history.map((e) {
              return ListTile(
                title: Text('Round ${e.roundNumber}: ${e.score ?? 0} pts'),
                subtitle: Text(
                    'Secret ${e.secret}, Guess ${e.guess} → Score ${e.score}'),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}
