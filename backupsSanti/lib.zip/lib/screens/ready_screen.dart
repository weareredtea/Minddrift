// lib/screens/ready_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:wavelength_clone_fresh/screens/setup_round_screen.dart';
import '../services/firebase_service.dart';
import '../models/player_status.dart';
import 'dice_overlay_screen.dart';

class ReadyScreen extends StatefulWidget {
  static const routeName = '/ready';
  final String roomId;
  const ReadyScreen({Key? key, required this.roomId}) : super(key: key);

  @override
  State<ReadyScreen> createState() => _ReadyScreenState();
}

class _ReadyScreenState extends State<ReadyScreen> {
  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();
    final roomId = widget.roomId;

    return Scaffold(
      appBar: AppBar(title: const Text('Get Ready')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text('Room Code: $roomId',
                style:
                    const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            Expanded(
              child: StreamBuilder<List<PlayerStatus>>(
                stream: fb.listenToReady(roomId),
                builder: (ctx, snap) {
                  if (!snap.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  final players = snap.requireData;
                  final allReady = players.every((p) => p.ready);

                  return ListView(
                    children: players
                        .map((p) => ListTile(
                              leading: Icon(
                                  p.ready
                                      ? Icons.check_circle
                                      : Icons.radio_button_unchecked,
                                  color: p.ready ? Colors.green : null),
                              title: Text(p.displayName),
                              trailing: Icon(
                                p.online
                                    ? Icons.circle
                                    : Icons.circle_outlined,
                                size: 12,
                                color: p.online ? Colors.green : Colors.red,
                              ),
                            ))
                        .toList(),
                  );
                },
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () => fb.setReady(
                  widget.roomId, !(snapLatestReady(widget.roomId, fb))),
              child: Text(
                  snapLatestReady(widget.roomId, fb) ? 'Cancel Ready' : 'I\'m Ready'),
            ),
            const SizedBox(height: 12),
            StreamBuilder<List<PlayerStatus>>(
              stream: fb.listenToReady(roomId),
              builder: (ctx, snap) {
                if (!snap.hasData) return const SizedBox();
                final players = snap.requireData;
                final allReady = players.every((p) => p.ready);
                return ElevatedButton(
                  onPressed: allReady
                      ? () => Navigator.pushReplacementNamed(
                            context,
                            SetupRoundScreen.routeName,
                            arguments: roomId,
                          )
                      : null,
                  child: const Text('All Ready—Start Round'),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  bool snapLatestReady(String roomId, FirebaseService fb) {
    // This hack reads the last known ready for current user
    // so the button label flips. You can improve by caching.
    // For now it defaults false.
    return false;
  }
}
