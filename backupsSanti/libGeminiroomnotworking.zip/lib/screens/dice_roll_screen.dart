// lib/screens/dice_roll_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:async'; // For Timer

import '../services/firebase_service.dart';
import '../models/round.dart'; // Import Round and Effect enum
import '../models/player_status.dart'; // Import for PlayerStatus
import 'home_screen.dart'; // Import for navigating back to home
import 'scoreboard_screen.dart'; // Import for navigating to scoreboard

class DiceRollScreen extends StatefulWidget {
  static const routeName = '/dice_roll';
  final String roomId;
  const DiceRollScreen({Key? key, required this.roomId}) : super(key: key);

  @override
  State<DiceRollScreen> createState() => _DiceRollScreenState();
}

class _DiceRollScreenState extends State<DiceRollScreen> {
  Timer? _timer;
  bool _animationComplete = false; // To control initial animation state
  bool _navigatedAway = false; // Prevent multiple navigations
  bool _showingLastPlayerDialog = false; // Flag for last player dialog

  @override
  void initState() {
    super.initState();
    // This listener will initiate the timer once the effectRolledAt timestamp appears
    // and handle the navigation.
    context.read<FirebaseService>().listenCurrentRound(widget.roomId).listen((round) {
      if (round.effectRolledAt != null && !_navigatedAway) {
        // Calculate remaining time
        final serverTime = DateTime.now(); // This assumes client time is reasonably close to server time
        final timeElapsed = serverTime.difference(round.effectRolledAt!);
        const duration = Duration(seconds: 3);
        final remainingDuration = duration - timeElapsed;

        if (remainingDuration.isNegative) {
          // If already past 3 seconds, navigate immediately
          _triggerTransition();
        } else {
          // If still within 3 seconds, set a timer for the remaining time
          setState(() {
            _animationComplete = true; // Show the final effect
          });
          _timer?.cancel(); // Cancel any existing timer
          _timer = Timer(remainingDuration, () {
            _triggerTransition();
          });
        }
      }
    });

    // Listen for player departures to show toast messages
    context.read<FirebaseService>().listenForPlayerDepartures(widget.roomId).listen((playerName) {
      if (playerName != null && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$playerName has exited the room.'),
            duration: const Duration(seconds: 2),
          ),
        );
      }
    });

    // Listen for last player standing scenario
    context.read<FirebaseService>().listenToLastPlayerStatus(widget.roomId).listen((status) {
      final onlinePlayerCount = status['onlinePlayerCount'] as int;
      final isLastPlayer = status['isLastPlayer'] as bool;
      final currentUserDisplayName = status['currentUserDisplayName'] as String;

      if (isLastPlayer && onlinePlayerCount == 1 && !_showingLastPlayerDialog && mounted) {
        setState(() {
          _showingLastPlayerDialog = true;
        });
        _showLastPlayerDialog(context, currentUserDisplayName, widget.roomId);
      } else if (!isLastPlayer && onlinePlayerCount > 1 && _showingLastPlayerDialog) {
        Navigator.of(context).popUntil((route) => route.isFirst);
      }
    });
  }

  void _triggerTransition() {
    if (!_navigatedAway) {
      setState(() {
        _navigatedAway = true;
      });
      // Call FirebaseService to update room status, which RoomNavigator will pick up
      context.read<FirebaseService>().transitionAfterDiceRoll(widget.roomId);
    }
  }

  // Helper to get a string representation of the effect
  String _getEffectDescription(Effect? effect) {
    switch (effect) {
      case Effect.doubleScore:
        return 'Double Score!';
      case Effect.halfScore:
        return 'Half Score!';
      case Effect.token:
        return 'Navigator gets a Token!';
      case Effect.reverseSlider:
        return 'Reverse Slider!';
      case Effect.noClue:
        return 'No Clue!';
      case Effect.blindGuess:
        return 'Blind Guess!';
      case Effect.none:
      default:
        return 'No Special Effect';
    }
  }

  Future<void> _showLastPlayerDialog(BuildContext context, String displayName, String roomId) async {
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext dialogContext) {
        final fb = dialogContext.read<FirebaseService>();
        return AlertDialog(
          title: const Text('You are the Last Player!'),
          content: Text('All other players have exited the room. You can invite other players, view the total score, or exit.'),
          actions: <Widget>[
            TextButton(
              child: const Text('Invite Friends'),
              onPressed: () {
                Navigator.of(dialogContext).pop();
                setState(() { _showingLastPlayerDialog = false; });
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Share room ID: $roomId')),
                );
              },
            ),
            TextButton(
              child: const Text('View Scoreboard'),
              onPressed: () {
                Navigator.of(dialogContext).pop();
                setState(() { _showingLastPlayerDialog = false; });
                Navigator.pushNamed(context, ScoreboardScreen.routeName, arguments: roomId);
              },
            ),
            TextButton(
              child: const Text('Exit to Home'),
              onPressed: () async {
                await fb.leaveRoom(roomId);
                Navigator.of(dialogContext).pop();
                setState(() { _showingLastPlayerDialog = false; });
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => const HomeScreen()),
                  (Route<dynamic> route) => false,
                );
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _showExitConfirmationDialog(BuildContext context, String roomId) async {
    final fb = context.read<FirebaseService>();
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Exit Game?'),
          content: const Text('Are you sure you want to exit this room? Other players will be notified.'),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(dialogContext).pop();
              },
            ),
            TextButton(
              child: const Text('Exit'),
              onPressed: () async {
                await fb.leaveRoom(roomId);
                Navigator.of(dialogContext).pop();
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => const HomeScreen()),
                  (Route<dynamic> route) => false,
                );
              },
            ),
          ],
        );
      },
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();

    return Scaffold(
      backgroundColor: Colors.black.withOpacity(0.7), // Semi-transparent overlay
      appBar: AppBar( // Added AppBar
        backgroundColor: Colors.transparent, // Transparent to blend with overlay
        elevation: 0, // No shadow
        actions: [
          IconButton(
            icon: const Icon(Icons.exit_to_app, color: Colors.white), // White icon for contrast
            onPressed: () => _showExitConfirmationDialog(context, widget.roomId),
          ),
        ],
      ),
      body: Center(
        child: StreamBuilder<Round>(
          stream: fb.listenCurrentRound(widget.roomId),
          builder: (ctx, snap) {
            if (!snap.hasData || snap.data!.effect == null) {
              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const CircularProgressIndicator(color: Colors.white),
                  const SizedBox(height: 20),
                  Text(
                    'Rolling the dice...',
                    style: TextStyle(fontSize: 24, color: Colors.white.withOpacity(0.9)),
                  ),
                ],
              );
            }

            final rolledEffect = snap.data!.effect!;
            final effectDescription = _getEffectDescription(rolledEffect);

            return Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (!_animationComplete) // Simple animation placeholder
                  const Text(
                    '🎲', // Dice emoji as a placeholder for animation
                    style: TextStyle(fontSize: 100),
                  ),
                if (_animationComplete) // Show final effect after "animation"
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.3),
                          spreadRadius: 5,
                          blurRadius: 7,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.casino, size: 60, color: Colors.deepOrange),
                        const SizedBox(height: 16),
                        Text(
                          effectDescription,
                          style: const TextStyle(
                            fontSize: 32,
                            fontWeight: FontWeight.bold,
                            color: Colors.deepOrange,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          rolledEffect == Effect.none ? '' : '(Round Score will be affected)',
                          style: const TextStyle(fontSize: 16, fontStyle: FontStyle.italic, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}
