// lib/screens/home_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/firebase_service.dart';
import 'ready_screen.dart'; // Import the ReadyScreen to use its routeName

class HomeScreen extends StatefulWidget {
  static const routeName = '/';
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _roomCtrl = TextEditingController();
  bool _loading = false;
  String? _error;

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();

    return Scaffold(
      appBar: AppBar(title: const Text('Wavelength Clone')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            if (_error != null) ...[
              Text(_error!, style: const TextStyle(color: Colors.red)),
              const SizedBox(height: 16),
            ],

            // --- Create Room ---
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _loading
                    ? null
                    : () async {
                        // ================== DEBUGGING ==================
                        print('--- DEBUG: Create Room button pressed. ---');
                        // ===============================================

                        setState(() {
                          _loading = true;
                          _error = null;
                        });
                        try {
                          print('DEBUG: Fetching room creation settings...');
                          final settings = await fb.fetchRoomCreationSettings();
                          
                          print('DEBUG: Calling createRoom function...');
                          final String roomId = await fb.createRoom(
                            settings['saboteurEnabled'] ?? false,
                            settings['diceRollEnabled']  ?? false,
                          );
                          print('DEBUG: createRoom function finished successfully. Room ID: $roomId');

                          if (mounted) {
                            print('DEBUG: Navigating to ReadyScreen...');
                            Navigator.pushReplacementNamed(
                              context,
                              ReadyScreen.routeName,
                              arguments: roomId,
                            );
                            print('DEBUG: Navigation command sent.');
                          }
                          
                        } catch (e) {
                          // ================== DEBUGGING ==================
                          print('--- DEBUG: AN ERROR WAS CAUGHT ---');
                          print('DEBUG: Error type: ${e.runtimeType}');
                          print('DEBUG: Error message: $e');
                          // ===============================================
                          setState(() => _error = 'Failed to create room: $e');
                        } finally {
                          if (mounted && _error != null) {
                            setState(() => _loading = false);
                          }
                        }
                      },
                child: _loading
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Text('Create Room', style: TextStyle(fontSize: 18)),
              ),
            ),

            const SizedBox(height: 32),
            const Text('OR', style: TextStyle(fontSize: 16)),
            const SizedBox(height: 32),

            // --- Join Room ---
            TextField(
              controller: _roomCtrl,
              textCapitalization: TextCapitalization.characters,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Enter Room ID',
              ),
            ),
            const SizedBox(height: 16),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _loading
                    ? null
                    : () async {
                        final code = _roomCtrl.text.trim().toUpperCase();
                        if (code.isEmpty) {
                          setState(() => _error = 'Please enter a room code.');
                          return;
                        }
                        setState(() {
                          _loading = true;
                          _error = null;
                        });
                        try {
                          final exists = await fb.roomExists(code);
                          if (!exists) {
                            throw 'Room "$code" not found.';
                          }
                          await fb.joinRoom(code);

                          // Also apply the direct navigation fix for joining a room
                           if (mounted) {
                            Navigator.pushReplacementNamed(
                              context,
                              ReadyScreen.routeName,
                              arguments: code,
                            );
                          }
                          
                        } catch (e) {
                          setState(() => _error = 'Join failed: $e');
                        } finally {
                          if (mounted && _error != null) {
                            setState(() => _loading = false);
                          }
                        }
                      },
                child: _loading
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Text('Join Room', style: TextStyle(fontSize: 18)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}