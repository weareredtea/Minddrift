// lib/screens/match_summary_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart'; // Import for DocumentSnapshot

import '../services/firebase_service.dart';
import '../pigeon/pigeon.dart'; // for PigeonUserDetails (assuming it includes totalScore now)
import 'home_screen.dart'; // To navigate back home
import '../models/round_history_entry.dart'; // Import RoundHistoryEntry
import '../models/player_status.dart'; // Import for PlayerStatus
import '../models/round.dart'; // Import for Effect enum (for history display)
import 'scoreboard_screen.dart'; // Import for navigating to scoreboard

class MatchSummaryScreen extends StatefulWidget { // Changed to StatefulWidget
  static const routeName = '/summary';
  final String roomId;
  const MatchSummaryScreen({Key? key, required this.roomId})
      : super(key: key);

  @override
  State<MatchSummaryScreen> createState() => _MatchSummaryScreenState();
}

class _MatchSummaryScreenState extends State<MatchSummaryScreen> {
  bool _showingLastPlayerDialog = false;

  // Helper to determine the group's performance description
  String _getGroupPerformance(int totalScore) {
    if (totalScore >= 25) {
      return 'Incredible';
    } else if (totalScore >= 21) {
      return 'Awesome';
    } else if (totalScore >= 10) {
      return 'Okay';
    } else {
      return 'Bad';
    }
  }

  // Helper to get effect description
  String _getEffectDescription(String? effectString) {
    if (effectString == null || effectString == Effect.none.toString().split('.').last) {
      return 'No Effect';
    }
    switch (effectString) {
      case 'doubleScore': return 'Double Score!';
      case 'halfScore': return 'Half Score!';
      case 'token': return 'Navigator gets a Token!';
      case 'reverseSlider': return 'Reverse Slider!';
      case 'noClue': return 'No Clue!';
      case 'blindGuess': return 'Blind Guess!';
      default: return 'Unknown Effect';
    }
  }

  @override
  void initState() {
    super.initState();
    // Listen for player departures to show toast messages
    context.read<FirebaseService>().listenForPlayerDepartures(widget.roomId).listen((playerName) {
      if (playerName != null && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$playerName has exited the room.'),
            duration: const Duration(seconds: 2),
          ),
        );
      }
    });

    // Listen for last player standing scenario
    context.read<FirebaseService>().listenToLastPlayerStatus(widget.roomId).listen((status) {
      final onlinePlayerCount = status['onlinePlayerCount'] as int;
      final isLastPlayer = status['isLastPlayer'] as bool;
      final currentUserDisplayName = status['currentUserDisplayName'] as String;

      if (isLastPlayer && onlinePlayerCount == 1 && !_showingLastPlayerDialog && mounted) {
        setState(() {
          _showingLastPlayerDialog = true;
        });
        _showLastPlayerDialog(context, currentUserDisplayName, widget.roomId);
      } else if (!isLastPlayer && onlinePlayerCount > 1 && _showingLastPlayerDialog) {
        Navigator.of(context).popUntil((route) => route.isFirst);
      }
    });
  }

  Future<void> _showLastPlayerDialog(BuildContext context, String displayName, String roomId) async {
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext dialogContext) {
        final fb = dialogContext.read<FirebaseService>();
        return AlertDialog(
          title: const Text('You are the Last Player!'),
          content: Text('All other players have exited the room. You can invite other players, view the total score, or exit.'),
          actions: <Widget>[
            TextButton(
              child: const Text('Invite Friends'),
              onPressed: () {
                Navigator.of(dialogContext).pop();
                setState(() { _showingLastPlayerDialog = false; });
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Share room ID: $roomId')),
                );
              },
            ),
            TextButton(
              child: const Text('View Scoreboard'),
              onPressed: () {
                Navigator.of(dialogContext).pop();
                setState(() { _showingLastPlayerDialog = false; });
                Navigator.pushNamed(context, ScoreboardScreen.routeName, arguments: roomId);
              },
            ),
            TextButton(
              child: const Text('Exit to Home'),
              onPressed: () async {
                await fb.leaveRoom(roomId);
                Navigator.of(dialogContext).pop();
                setState(() { _showingLastPlayerDialog = false; });
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => const HomeScreen()),
                  (Route<dynamic> route) => false,
                );
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _showExitConfirmationDialog(BuildContext context, String roomId) async {
    final fb = context.read<FirebaseService>();
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Exit Game?'),
          content: const Text('Are you sure you want to exit this room? Other players will be notified.'),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(dialogContext).pop();
              },
            ),
            TextButton(
              child: const Text('Exit'),
              onPressed: () async {
                await fb.leaveRoom(roomId);
                Navigator.of(dialogContext).pop();
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => const HomeScreen()),
                  (Route<dynamic> route) => false,
                );
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Match Summary'),
        actions: [
          IconButton(
            icon: const Icon(Icons.exit_to_app),
            onPressed: () => _showExitConfirmationDialog(context, widget.roomId),
          ),
        ],
      ),
      body: FutureBuilder<List<List<dynamic>>>( // Combine two futures
        future: Future.wait([
          fb.fetchPlayersWithScores(widget.roomId), // Fetches player total scores
          fb.fetchHistory(widget.roomId), // Fetches individual round history
        ]),
        builder: (ctx, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snap.hasData || snap.data == null) {
            return const Center(child: Text('Error loading match data.'));
          }

          final List<PigeonUserDetails> players = snap.data![0].cast<PigeonUserDetails>();
          final List<RoundHistoryEntry> roundHistory = snap.data![1].cast<RoundHistoryEntry>();

          if (players.isEmpty) {
            return const Center(child: Text('No players found for this match.'));
          }

          // Sort players by total score in descending order
          players.sort((a, b) => (b.totalScore ?? 0).compareTo(a.totalScore ?? 0));

          // Calculate total group score from round history
          final int totalGroupScore = roundHistory.fold(0, (sum, entry) => sum + (entry.score ?? 0));
          final String groupPerformance = _getGroupPerformance(totalGroupScore);

          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                const Text(
                  'Final Scores!',
                  style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),

                // Display Group Total Score and Performance
                Text(
                  'Group Total Score: $totalGroupScore points',
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.deepPurple),
                ),
                Text(
                  'Performance: $groupPerformance',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    color: groupPerformance == 'Incredible' ? Colors.green.shade700
                        : groupPerformance == 'Awesome' ? Colors.blue.shade700
                        : groupPerformance == 'Okay' ? Colors.orange.shade700
                        : Colors.red.shade700,
                  ),
                ),
                const SizedBox(height: 24),

                // Section for Individual Round Scores
                Text(
                  'Individual Round Scores:',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.grey[700]),
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: ListView.builder(
                    itemCount: roundHistory.length,
                    itemBuilder: (context, index) {
                      final entry = roundHistory[index];
                      return Card(
                        margin: const EdgeInsets.symmetric(vertical: 4.0),
                        elevation: 1,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        child: Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('Round ${entry.roundNumber}:', style: const TextStyle(fontSize: 16)),
                              Text('${entry.score ?? 0} pts', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                              if (entry.effect != null && entry.effect != Effect.none.toString().split('.').last)
                                Text('(${_getEffectDescription(entry.effect)})', style: TextStyle(fontStyle: FontStyle.italic, color: Colors.deepOrange, fontSize: 14)),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 24),

                // Section for Player Total Scores (remains as is)
                Text(
                  'Player Overall Scores:',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.grey[700]),
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: ListView.builder(
                    itemCount: players.length,
                    itemBuilder: (context, index) {
                      final player = players[index];
                      return Card(
                        margin: const EdgeInsets.symmetric(vertical: 8.0),
                        elevation: 3,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        color: index == 0 ? Colors.amber.shade100 : Theme.of(context).cardColor, // Highlight winner
                        child: ListTile(
                          leading: Text(
                            '#${index + 1}', // Rank
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: index == 0 ? Colors.amber.shade700 : null,
                            ),
                          ),
                          title: Text(
                            player.displayName,
                            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
                          ),
                          trailing: Row( // Use a Row to display score and tokens
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (player.tokens != null && player.tokens! > 0)
                                Padding(
                                  padding: const EdgeInsets.only(right: 8.0),
                                  child: Text(
                                    '${player.tokens!} 💎', // Diamond emoji for tokens
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.blue.shade700,
                                    ),
                                  ),
                                ),
                              Text(
                                '${player.totalScore ?? 0} pts',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: index == 0 ? Colors.amber.shade700 : Colors.blueAccent,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: () {
                    // Navigate back to the Home screen
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (context) => const HomeScreen()),
                      (Route<dynamic> route) => false,
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 32),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text(
                    'Return to Home',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
