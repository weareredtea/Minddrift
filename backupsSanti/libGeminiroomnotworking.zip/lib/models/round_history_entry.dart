// lib/models/round_history_entry.dart

import 'package:cloud_firestore/cloud_firestore.dart';

class RoundHistoryEntry {
  final int roundNumber;
  final int? secret;
  final int? guess;
  final int? score;
  final int? guessA, scoreA, guessB, scoreB; // Not currently used, but kept from original
  final DateTime timestamp;
  final String? effect; // NEW: Added effect field as a String

  RoundHistoryEntry({
    required this.roundNumber,
    this.secret,
    this.guess,
    this.score,
    this.guessA,
    this.scoreA,
    this.guessB,
    this.scoreB,
    required this.timestamp,
    this.effect, // NEW: Include in constructor
  });

  factory RoundHistoryEntry.fromMap(Map<String, dynamic> m) {
    return RoundHistoryEntry(
      roundNumber: m['roundNumber'] as int,
      secret:      m['secret']      as int?,
      guess:       m['guess']       as int?,
      score:       m['score']       as int?,
      guessA:      m['guessA']      as int?,
      scoreA:      m['scoreA']      as int?,
      guessB:      m['guessB']      as int?,
      scoreB:      m['guessB']      as int?,
      timestamp:   (m['timestamp'] as Timestamp).toDate(),
      effect:      m['effect']      as String?, // NEW: Parse effect
    );
  }
}
