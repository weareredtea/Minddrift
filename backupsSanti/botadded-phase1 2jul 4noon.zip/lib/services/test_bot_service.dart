// lib/services/test_bot_service.dart

import 'dart:async';
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:wavelength_clone_fresh/models/avatar.dart';
import 'package:wavelength_clone_fresh/models/round.dart';
import 'package:wavelength_clone_fresh/services/firebase_service.dart';

class TestBotService {
  final String roomId;
  final FirebaseService _firebaseService;
  final String botUid = 'test-bot-001'; // A unique, hardcoded ID for our bot
  final Random _random = Random();
  StreamSubscription? _roomSubscription;

  TestBotService(this.roomId, this._firebaseService) {
    print('🤖 TestBotService initialized for room: $roomId');
    _listenToRoomChanges();
  }

  // The "brain" of the bot. It listens to the game state and decides what to do.
  void _listenToRoomChanges() {
    _roomSubscription = _firebaseService.roomDocRef(roomId).snapshots().listen((roomSnap) async {
      if (!roomSnap.exists) {
        dispose(); // Room has been deleted, stop the bot.
        return;
      }
      final roomStatus = roomSnap.data()?['status'] as String?;
      final roundSnap = await _firebaseService.roundDocRef(roomId).get();
      final round = Round.fromMap(roundSnap.data() ?? {});
      final myRole = round.roles?[botUid];

      print('🤖 Bot observes room status: $roomStatus, my role: $myRole');

      // Add a delay to make the bot's actions feel more natural
      await Future.delayed(Duration(seconds: _random.nextInt(3) + 2));

      switch (roomStatus) {
        case 'lobby':
        case 'ready_phase':
          await _firebaseService.setReady(roomId, true, uid: botUid);
          print('🤖 Bot is ready in the lobby.');
          break;

        case 'clue_submission':
          if (myRole == Role.Navigator) {
            final secret = round.secretPosition ?? 50;
            final clue = _generateRandomClue();
            await _firebaseService.submitClue(roomId, secret, clue);
            print('🤖 Bot (Navigator) submitted clue: "$clue"');
          }
          break;

        case 'guessing':
          if (myRole == Role.Seeker || myRole == Role.Saboteur) {
            final randomGuess = _random.nextInt(101).toDouble();
            await _firebaseService.updateGroupGuess(roomId, randomGuess);
            await _firebaseService.setGuessReady(roomId, true, uid: botUid);
            print('🤖 Bot (Seeker) made a guess at: $randomGuess');
          }
          break;
        
        case 'round_end':
           await _firebaseService.setReady(roomId, true, uid: botUid);
           print('🤖 Bot is ready for the next round.');
           break;
      }
    });
  }

  String _generateRandomClue() {
    const words = ['Sky', 'Ocean', 'Fire', 'Earth', 'Love', 'Hate', 'Fast', 'Slow', 'Big', 'Small', 'Cat', 'Dog', 'Sun', 'Moon', 'War', 'Peace'];
    words.shuffle();
    return words.take(4).join(' ');
  }

  // Call this to stop the bot's listeners
  void dispose() {
    print('🤖 TestBotService disposed.');
    _roomSubscription?.cancel();
  }
}