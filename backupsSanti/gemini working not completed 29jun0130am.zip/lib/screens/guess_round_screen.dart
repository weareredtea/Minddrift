// lib/screens/guess_round_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../services/firebase_service.dart';
import '../widgets/slider_dial.dart';
import '../models/player_status.dart';
import 'result_screen.dart';

class GuessRoundScreen extends StatefulWidget {
  static const routeName = '/guess';
  final String roomId;
  const GuessRoundScreen({Key? key, required this.roomId}) : super(key: key);

  @override
  State<GuessRoundScreen> createState() => _GuessRoundScreenState();
}

class _GuessRoundScreenState extends State<GuessRoundScreen> {
  bool _navigated = false;

  @override
  Widget build(BuildContext context) {
    final fb  = context.read<FirebaseService>();
    final uid = fb.currentUserUid;

    return Scaffold(
      appBar: AppBar(title: const Text('Seekers: Make the Guess')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Clue display
            StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
              stream: fb.roundDocRef(widget.roomId).snapshots(),
              builder: (ctx, snap) {
                if (!snap.hasData) {
                  return const CircularProgressIndicator();
                }
                final data = snap.data!.data()!;
                final clue = data['clue'] as String? ?? '';
                return Text(
                  clue.isEmpty 
                    ? 'Waiting for the Navigator…' 
                    : 'Clue: "$clue"',
                  style: const TextStyle(fontSize: 24),
                  textAlign: TextAlign.center,
                );
              },
            ),

            const SizedBox(height: 24),

            // Shared slider
            StreamBuilder<double>(
              stream: fb.listenGroupGuess(widget.roomId),
              builder: (ctx, snap) {
                final pos = snap.data ?? 50.0;
                return SliderDial(
                  value: pos,
                  divisions: 100,
                  onChanged: (v) => fb.updateGroupGuess(widget.roomId, v),
                );
              },
            ),

            const SizedBox(height: 16),

            // Seekers ready list + toggle
            Expanded(
              child: StreamBuilder<List<PlayerStatus>>(
                stream: fb.listenGuessReady(widget.roomId),
                builder: (ctx, ss) {
                  if (!ss.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  final players = ss.data!;
                  final me = players.firstWhere(
                    (p) => p.uid == uid,
                    orElse: () => PlayerStatus(
                      uid: uid,
                      displayName: 'You',
                      ready: false,
                      online: true,
                    ),
                  );
                  final allReady = players.every((p) => p.ready);

                  return Column(
                    children: [
                      Expanded(
                        child: ListView(
                          children: players.map((p) {
                            return ListTile(
                              leading: Icon(
                                p.ready
                                    ? Icons.check_circle
                                    : Icons.radio_button_unchecked,
                                color: p.ready ? Colors.green : null,
                              ),
                              title: Text(p.displayName),
                              trailing: Icon(
                                p.online
                                    ? Icons.circle
                                    : Icons.circle_outlined,
                                size: 12,
                                color: p.online ? Colors.green : Colors.red,
                              ),
                            );
                          }).toList(),
                        ),
                      ),

                      ElevatedButton(
                        onPressed: () =>
                            fb.setGuessReady(widget.roomId, !me.ready),
                        child: Text(
                          me.ready ? 'Cancel Ready' : 'I\'m Ready',
                        ),
                      ),

                      const SizedBox(height: 12),
                     // lib/screens/guess_round_screen.dart

// ... inside the StreamBuilder
if (allReady && !_navigated)
  ElevatedButton(
    onPressed: () {
      setState(() { _navigated = true; });
      // Call the new central function instead of just navigating
      fb.finalizeRound(widget.roomId).then((_) {
        // Now navigate after the round is finalized
        Navigator.pushReplacementNamed(
          context,
          ResultScreen.routeName,
          arguments: widget.roomId,
        );
      });
    },
    child: const Text('All Ready—Show Results'),
  ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
