// lib/screens/home_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/firebase_service.dart';
import 'ready_screen.dart';

class HomeScreen extends StatefulWidget {
  static const routeName = '/';
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _roomCtrl = TextEditingController();
  bool _loading = false;

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();

    return Scaffold(
      appBar: AppBar(title: const Text('Wavelength Clone')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            ElevatedButton(
              onPressed: _loading
                  ? null
                  : () async {
                      setState(() => _loading = true);
                      final id = (await fb.createRoom()).toUpperCase();
                      setState(() => _loading = false);
                      Navigator.pushReplacementNamed(
                        context,
                        ReadyScreen.routeName,
                        arguments: id,
                      );
                    },
              child: _loading
                  ? const CircularProgressIndicator()
                  : const Text('Create Room'),
            ),
            const SizedBox(height: 24),
            TextField(
              controller: _roomCtrl,
              decoration: const InputDecoration(labelText: 'Enter Room ID'),
              textCapitalization: TextCapitalization.characters,
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _loading
                  ? null
                  : () async {
                      setState(() => _loading = true);
                      final code = _roomCtrl.text.trim().toUpperCase();
                      final exists = await fb.roomExists(code);
                      setState(() => _loading = false);
                      if (!exists) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Room not found')),
                        );
                        return;
                      }
                      await fb.joinRoom(code);
                      Navigator.pushReplacementNamed(
                        context,
                        ReadyScreen.routeName,
                        arguments: code,
                      );
                    },
              child: _loading
                  ? const CircularProgressIndicator()
                  : const Text('Join Room'),
            ),
          ],
        ),
      ),
    );
  }
}
