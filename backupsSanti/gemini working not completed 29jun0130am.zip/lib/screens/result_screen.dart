// lib/screens/result_screen.dart

import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:wavelength_clone_fresh/screens/match_summary_screen.dart';
import 'package:wavelength_clone_fresh/screens/ready_screen.dart';
import '../services/firebase_service.dart';
import '../models/player_status.dart';

class ResultScreen extends StatelessWidget {
  static const routeName = '/result';
  final String roomId;
  const ResultScreen({Key? key, required this.roomId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();

    return Scaffold(
      appBar: AppBar(title: const Text('Round Results')),
      // lib/screens/result_screen.dart

// ... inside build method
body: StreamBuilder<Map<String, dynamic>>(
  stream: fb
      .roundDocRef(roomId)
      .snapshots()
      .map((snap) => snap.data() ?? {}),
  builder: (ctx, snap) {
    if (!snap.hasData || snap.data!.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    final data     = snap.requireData;
    // Read data directly from Firestore
    final secret   = (data['secretPosition'] as num?)?.toInt() ?? 0;
    final guess    = (data['groupGuessPosition'] as num?)?.toInt() ?? 0;
    final score    = (data['finalScore'] as num?)?.toInt() ?? 0; // Read the saved score

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Secret was: $secret',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 24),
          Text('Your guess: $guess',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 48),
          Text('Score for this round: $score',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 32, color: Colors.blue)),
        ],
      ),
    );
  },
),
// ...
      bottomNavigationBar: NextRoundControls(roomId: roomId),
    );
  }
}

class NextRoundControls extends StatefulWidget {
  final String roomId;
  const NextRoundControls({Key? key, required this.roomId}) : super(key: key);

  @override
  State<NextRoundControls> createState() => _NextRoundControlsState();
}


class _NextRoundControlsState extends State<NextRoundControls> {
  StreamSubscription? _subscription;

  @override
  void initState() {
    super.initState();
    final fb = context.read<FirebaseService>();
    // Listen for game state changes to navigate automatically
    _subscription = FirebaseFirestore.instance
        .collection('rooms')
        .doc(widget.roomId)
        .snapshots()
        .listen((roomSnap) {
      final state = roomSnap.data()?['gameState'] as String?;
      if (state == 'READY') {
        Navigator.pushReplacementNamed(context, ReadyScreen.routeName,
            arguments: widget.roomId);
      } else if (state == 'SUMMARY') {
        Navigator.pushReplacementNamed(context, MatchSummaryScreen.routeName,
            arguments: widget.roomId);
      }
    });
  }
  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();
    final roomId = widget.roomId;

    return Padding(
      padding: const EdgeInsets.all(16),
      child: ElevatedButton(
        onPressed: () {
          // A single player pressing this will trigger the next round for everyone
          fb.prepareForNextRound(roomId);
        },
        child: const Text('Continue'),
      ),
    );
  }
}