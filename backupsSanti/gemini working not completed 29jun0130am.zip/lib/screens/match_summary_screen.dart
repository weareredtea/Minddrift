// lib/screens/match_summary_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:wavelength_clone_fresh/models/round_history_entry.dart';
import '../services/firebase_service.dart';
import '../pigeon/pigeon.dart'; // for PigeonUserDetails

class MatchSummaryScreen extends StatelessWidget {
  static const routeName = '/summary';
  final String roomId;
  const MatchSummaryScreen({Key? key, required this.roomId})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();

    return Scaffold(
      appBar: AppBar(title: const Text('Match Summary')),
      body: FutureBuilder<List<RoundHistoryEntry>>(
      future: fb.fetchHistory(roomId),
      builder: (ctx, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        final history = snap.data ?? [];
        final totalScore = history.fold<int>(0, (prev, e) => prev + (e.score ?? 0));
        
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Text(
                'Game Over!',
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              const SizedBox(height: 24),
              Text(
                'Final Score: $totalScore',
                style: Theme.of(context).textTheme.headlineLarge,
              ),
              const SizedBox(height: 24),
              const Text('Round History:'),
              Expanded(
                child: ListView(
                  children: history.map((e) {
                    return Card(
                      child: ListTile(
                        title: Text('Round ${e.roundNumber}: ${e.score ?? 0} pts'),
                        subtitle: Text('Secret was ${e.secret}, Team guessed ${e.guess}'),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        );
      }
    ),
    );
}
}