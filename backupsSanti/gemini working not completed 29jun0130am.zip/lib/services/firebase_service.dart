import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../models/player_status.dart';
import '../models/round.dart';
import '../models/round_history_entry.dart';
import '../pigeon/pigeon.dart';

class FirebaseService with ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final Random _rnd = Random();

  String get currentUserUid => _auth.currentUser!.uid;
  String _randomCode(int n) =>
      List.generate(n, (_) => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'[_rnd.nextInt(36)])
          .join();

  Future<User> signInAnonymously() async {
    final cred = await _auth.signInAnonymously();
    return cred.user!;
  }

  Future<bool> roomExists(String roomId) async =>
      (await _db.collection('rooms').doc(roomId).get()).exists;

  Future<String> createRoom() async {
    final user = await signInAnonymously();
    String roomId;
    do {
      roomId = _randomCode(4);
    } while (await roomExists(roomId));

    await _db.collection('rooms').doc(roomId).set({
      'creator': user.uid,
      'createdAt': FieldValue.serverTimestamp(),
      'roundNumber': 1,
      'saboteurEnabled': false,
      'teamBattleEnabled': false,
    });
    await joinRoom(roomId);
    await seedCategories(roomId);
    notifyListeners();
    return roomId;
  }

  // lib/services/firebase_service.dart

Future<void> finalizeRound(String roomId) async {
  final batch = _db.batch();
  final roomRef = _db.collection('rooms').doc(roomId);
  final currentRoundRef = roundDocRef(roomId);

  // Get the current round data to perform calculations
  final roundSnap = await currentRoundRef.get();
  final roundData = roundSnap.data();
  if (roundData == null) return; // Should not happen

  final secret = (roundData['secretPosition'] as num?)?.toInt() ?? 0;
  final guess = (roundData['groupGuessPosition'] as num?)?.toInt() ?? 0;
  final distance = (secret - guess).abs();
  final score = distance <= 5 ? 6 :
                distance <= 10 ? 3 :
                distance <= 20 ? 1 : 0;

  // 1. Update the current round document with the final score
  batch.update(currentRoundRef, {'finalScore': score});

  // 2. Create a history entry for this round
  final roomSnap = await roomRef.get();
  final roundNumber = roomSnap.data()?['roundNumber'] as int? ?? 1;
  final historyRef = roomRef.collection('history').doc('round_$roundNumber');

  batch.set(historyRef, {
    'roundNumber': roundNumber,
    'secret': secret,
    'guess': guess,
    'score': score,
    'timestamp': FieldValue.serverTimestamp(),
    // You can add clue, roles, etc. to history here if desired
  });

  // 3. Mark the room so players can proceed
  batch.update(roomRef, {'roundFinalized': true});

  await batch.commit();
}


// lib/services/firebase_service.dart

Future<void> prepareForNextRound(String roomId) async {
  final roomRef = _db.collection('rooms').doc(roomId);
  final roomSnap = await roomRef.get();
  final currentRound = roomSnap.data()?['roundNumber'] as int? ?? 1;

  if (currentRound >= 5) { // GAME OVER CONDITION
    await roomRef.update({'gameState': 'SUMMARY'});
  } else {
    // Game is not over, setup for the next round
    final batch = _db.batch();

    // 1. Increment round number
    batch.update(roomRef, {'roundNumber': FieldValue.increment(1)});

    // 2. Reset flags for the next round
    batch.update(roomRef, {
      'roundStarted': false,
      'roundFinalized': false,
      'gameState': 'READY',
    });

    // 3. Reset all players' ready statuses
    final playersSnap = await roomRef.collection('players').get();
    for (var doc in playersSnap.docs) {
      batch.update(doc.reference, {'ready': false, 'guessReady': false});
    }

    // 4. Clear the current round document for a fresh start
    batch.set(roundDocRef(roomId), {});

    await batch.commit();
  }
}
  Future<void> joinRoom(String roomId) async {
    final user = await signInAnonymously();
    await _db
        .collection('rooms')
        .doc(roomId)
        .collection('players')
        .doc(user.uid)
        .set({
      'displayName': user.uid,
      'ready': false,
      'guessReady': false,
      'online': true,
      'lastSeen': FieldValue.serverTimestamp(),
    });
    notifyListeners();
  }

  Future<void> seedCategories(String roomId) async {
    final cats = [
      {'id':'hot_cold','left':'HOT','right':'COLD'},
      {'id':'calm_noisy','left':'CALM','right':'NOISY'},
      {'id':'soft_rough','left':'SOFT','right':'ROUGH'},
      // ... add 27 more ...
    ];
    final col = _db.collection('rooms').doc(roomId).collection('categories');
    for (var c in cats) {
      await col.doc(c['id']!).set(c);
    }
  }

  DocumentReference<Map<String,dynamic>> roundDocRef(String roomId) =>
      _db.collection('rooms').doc(roomId).collection('rounds').doc('current');

  Future<void> assignRoles(String roomId) async {
    final playersSnap = await _db.collection('rooms').doc(roomId).collection('players').get();
    final uids = playersSnap.docs.map((d) => d.id).toList()..shuffle();
    if (uids.isEmpty) return;
    final rolesMap = <String,String>{};
    rolesMap[uids[0]] = 'Navigator';
    for (var i = 1; i < uids.length; i++) {
      rolesMap[uids[i]] = 'Seeker';
    }
    await roundDocRef(roomId).set({'roles': rolesMap}, SetOptions(merge: true));
  }

  Future<void> assignRandomPosition(String roomId) async {
    final pos = _rnd.nextInt(101);
    await roundDocRef(roomId).set({'secretPosition': pos}, SetOptions(merge: true));
  }

  Future<void> submitClue(String roomId, int secret, String clue) async {
    await roundDocRef(roomId).set({
      'secretPosition': secret,
      'clue': clue,
      'creator': currentUserUid
    }, SetOptions(merge: true));
  }

  Future<void> submitGuess(String roomId, int guess) async {
    await roundDocRef(roomId).set({
      'groupGuessPosition': guess
    }, SetOptions(merge: true));
  }

  Stream<List<PlayerStatus>> listenToReady(String roomId) =>
      _db.collection('rooms').doc(roomId).collection('players').snapshots().map((snap) {
        return snap.docs.map((d) => PlayerStatus.fromSnapshot(d)).toList();
      });

  Future<void> setReady(String roomId, bool ready) => _db
      .collection('rooms')
      .doc(roomId)
      .collection('players')
      .doc(currentUserUid)
      .update({'ready': ready});

  Stream<double> listenGroupGuess(String roomId) =>
      roundDocRef(roomId).snapshots().map((snap) {
        final data = snap.data();
        return (data?['groupGuessPosition'] as num?)?.toDouble() ?? 50.0;
      });

  /// Write the shared slider position for all Seekers.
  Future<void> updateGroupGuess(String roomId, double pos) {
    return roundDocRef(roomId)
        .set({'groupGuessPosition': pos}, SetOptions(merge: true));
  }

  /// Called by the host to kick off a new round:
  Future<void> startRound(String roomId) async {
    // 1) assign roles & secret
    await assignRoles(roomId);
    await assignRandomPosition(roomId);
    // 2) mark the room as started
    await _db.collection('rooms').doc(roomId)
      .update({'roundStarted': true});
  }

  /// Stream that flips true when startRound(...) is called
  Stream<bool> listenRoundStarted(String roomId) {
    return _db.collection('rooms').doc(roomId)
      .snapshots()
      .map((snap) => (snap.data()?['roundStarted'] as bool?) ?? false);
  }


  /// Fetch all players in this room as PigeonUserDetails.
  Future<List<PigeonUserDetails>> fetchPlayers(String roomId) async {
    final col = await _db
        .collection('rooms').doc(roomId)
        .collection('players')
        .get();
    return col.docs.map((doc) {
      final data = doc.data();
      return PigeonUserDetails(
        uid:         doc.id,
        displayName: data['displayName'] as String? ?? 'Anonymous',
      );
    }).toList();
  }


  Future<void> setGuessReady(String roomId, bool ready) => _db
      .collection('rooms')
      .doc(roomId)
      .collection('players')
      .doc(currentUserUid)
      .update({'guessReady': ready});

  Stream<double> listenGuessSlider(String roomId) => listenGroupGuess(roomId);

  Stream<List<PlayerStatus>> listenGuessReady(String roomId) =>
      _db.collection('rooms').doc(roomId).collection('players').snapshots().map((snap) {
        return snap.docs
            .map((d) => PlayerStatus(
                  uid: d.id,
                  displayName: d.data()['displayName'] as String? ?? 'Anonymous',
                  ready: d.data()['guessReady'] as bool? ?? false,
                  online: d.data()['online'] as bool? ?? false,
                ))
            .toList();
      });

  Future<List<RoundHistoryEntry>> fetchHistory(String roomId) async {
    final snap = await _db
      .collection('rooms').doc(roomId)
      .collection('history')
      .orderBy('roundNumber')
      .get();
    return snap.docs.map((d)=>RoundHistoryEntry.fromMap(d.data())).toList();
  }

  Future<void> incrementRoundNumber(String roomId) => _db
      .collection('rooms').doc(roomId)
      .update({'roundNumber': FieldValue.increment(1)});
}
