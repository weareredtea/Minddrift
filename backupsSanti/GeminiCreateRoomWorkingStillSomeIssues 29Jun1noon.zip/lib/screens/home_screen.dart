// lib/screens/home_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/firebase_service.dart';
import 'ready_screen.dart';
import 'settings_screen.dart';


class HomeScreen extends StatefulWidget {
  static const routeName = '/';
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _roomCtrl = TextEditingController();
  bool _loading = false;
  String? _error;

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Wavelength Clone'),
        // Add the settings icon button here
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              Navigator.pushNamed(context, SettingsScreen.routeName);
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // ... (rest of the home screen body is the same)
             ElevatedButton(
              onPressed: _loading
                  ? null
                  : () async {
                      setState(() => _loading = true);
                      try {
                        final settings = await fb.fetchRoomCreationSettings();
                        final id = await fb.createRoom(
                            settings['saboteurEnabled'] ?? false,
                            settings['diceRollEnabled']  ?? false,
                        );
                        if (mounted) {
                          Navigator.pushReplacementNamed(
                            context,
                            ReadyScreen.routeName,
                            arguments: id,
                          );
                        }
                      } catch(e) {
                          setState(() {
                              _error = "Error: $e";
                              _loading = false;
                          });
                      }
                    },
              child: _loading
                  ? const CircularProgressIndicator()
                  : const Text('Create Room'),
            ),
            const SizedBox(height: 24),
            TextField(
              controller: _roomCtrl,
              decoration: const InputDecoration(labelText: 'Enter Room ID'),
              textCapitalization: TextCapitalization.characters,
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _loading
                  ? null
                  : () async {
                      setState(() => _loading = true);
                      try {
                        final code = _roomCtrl.text.trim().toUpperCase();
                        if (code.isEmpty) {
                            setState(() {
                                _error = "Please enter a room code.";
                                _loading = false;
                            });
                            return;
                        }
                        final exists = await fb.roomExists(code);
                        if (!exists) {
                           setState(() {
                                _error = "Room not found.";
                                _loading = false;
                            });
                           return;
                        }
                        await fb.joinRoom(code);
                        if (mounted) {
                           Navigator.pushReplacementNamed(
                            context,
                            ReadyScreen.routeName,
                            arguments: code,
                          );
                        }
                      } catch (e) {
                          setState(() {
                                _error = "Error joining room: $e";
                                _loading = false;
                            });
                      }
                    },
              child: _loading
                  ? const CircularProgressIndicator()
                  : const Text('Join Room'),
            ),
          ],
        ),
      ),
    );
  }
}