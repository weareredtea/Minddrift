// lib/screens/role_reveal_screen.dart

import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/audio_service.dart';
import '../services/firebase_service.dart';
import '../models/round.dart';
import '../theme/app_theme.dart';

class RoleRevealScreen extends StatefulWidget {
  final String roomId;
  const RoleRevealScreen({super.key, required this.roomId});

  @override
  State<RoleRevealScreen> createState() => _RoleRevealScreenState();
}

class _RoleRevealScreenState extends State<RoleRevealScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  bool _isFlipped = false;
  final AudioService _audioService = AudioService();

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _animation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    // Trigger the flip after a short delay
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) {
        _controller.forward();
        setState(() => _isFlipped = true);
      }
    });

    // Automatically move to the next screen after the animation
    Future.delayed(const Duration(seconds: 5), () {
      final fb = context.read<FirebaseService>();
      // Only the host should trigger the transition
      fb.roomDocRef(widget.roomId).get().then((doc) {
        if (doc.data()?['creator'] == fb.currentUserUid) {
          fb.transitionAfterRoleReveal(widget.roomId);
        }
      });
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();

    return Scaffold(
      body: Center(
        child: AnimatedBuilder(
          animation: _animation,
          builder: (context, child) {
            final angle = _animation.value * pi;
            final transform = Matrix4.identity()
              ..setEntry(3, 2, 0.001)
              ..rotateY(angle);

            return Transform(
              transform: transform,
              alignment: Alignment.center,
              child: _animation.value <= 0.5
                  ? const RoleCard(isFront: true)
                  : Transform(
                      transform: Matrix4.identity()..rotateY(pi),
                      alignment: Alignment.center,
                      child: StreamBuilder<Role>(
                        stream: fb.listenMyRole(widget.roomId),
                        builder: (context, snapshot) {
                          final myRole = snapshot.data ?? Role.Seeker;
                          return RoleCard(role: myRole);
                        },
                      ),
                    ),
            );
          },
        ),
      ),
    );
  }
}

class RoleCard extends StatelessWidget {
  final bool isFront;
  final Role? role;

  const RoleCard({
    super.key,
    this.isFront = false,
    this.role,
  });

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    String title;
    String description;
    IconData icon;
    Color color;

    if (isFront) {
      title = 'Your Role Is...';
      description = '';
      icon = Icons.help_outline_rounded;
      color = AppColors.surface;
    } else {
      switch (role) {
        case Role.Navigator:
          title = 'Navigator';
          description = 'Give a clever clue to guide your team!';
          icon = Icons.explore_rounded;
          color = AppColors.accent;
          break;
        case Role.Saboteur:
          title = 'Saboteur';
          description = 'Subtly mislead the team to make them miss!';
          icon = Icons.remove_red_eye_rounded;
          color = AppColors.accentVariant;
          break;
        default:
          title = 'Seeker';
          description = 'Work with your team to guess the position!';
          icon = Icons.search_rounded;
          color = AppColors.primary;
      }
    }

    return Card(
      color: color,
      child: Container(
        width: 300,
        height: 400,
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 80, color: AppColors.onPrimary),
            const SizedBox(height: 24),
            Text(title, style: textTheme.displayMedium?.copyWith(color: AppColors.onPrimary)),
            if (description.isNotEmpty) ...[
              const SizedBox(height: 16),
              Text(
                description,
                style: textTheme.titleLarge?.copyWith(color: AppColors.onPrimary.withOpacity(0.8)),
                textAlign: TextAlign.center,
              ),
            ]
          ],
        ),
      ),
    );
  }
}
