// lib/main.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart'; // Import Firestore
import 'package:firebase_auth/firebase_auth.dart'; // Import FirebaseAuth

import 'firebase_options.dart';
import 'services/firebase_service.dart';
import 'screens/home_screen.dart';
import 'screens/lobby_screen.dart'; // Keeping lobby screen, though current flow skips it
import 'screens/ready_screen.dart';
import 'screens/setup_round_screen.dart';
import 'screens/waiting_clue_screen.dart';
import 'screens/guess_round_screen.dart';
import 'screens/result_screen.dart';
import 'screens/scoreboard_screen.dart';
import 'screens/match_summary_screen.dart';
import 'screens/dice_roll_screen.dart'; // Import the new DiceRollScreen
import 'models/round.dart'; // Import Role enum

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => FirebaseService(),
      child: Consumer<FirebaseService>(
        builder: (context, fb, child) {
          // Listen for Firebase Auth state changes
          return StreamBuilder<User?>(
            stream: FirebaseAuth.instance.authStateChanges(),
            builder: (context, authSnapshot) {
              if (authSnapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }

              // After user is authenticated, use RoomNavigator or HomeScreen
              return MaterialApp(
                title: 'Wavelength Clone',
                theme: ThemeData(useMaterial3: true),
                // Home screen is the entry point if no room or auth issues
                home: authSnapshot.hasData ? RoomNavigator() : const HomeScreen(),
                onGenerateRoute: (settings) {
                  final args = settings.arguments;
                  // If no valid roomId string, bounce home
                  if (args is! String || args.isEmpty) {
                    return MaterialPageRoute(
                      builder: (_) => const HomeScreen(),
                    );
                  }
                  // All other navigations go through here
                  switch (settings.name) {
                    case LobbyScreen.routeName:
                      return MaterialPageRoute(
                        builder: (_) => LobbyScreen(roomId: args),
                      );
                    case ReadyScreen.routeName:
                      return MaterialPageRoute(
                        builder: (_) => ReadyScreen(roomId: args),
                      );
                    case SetupRoundScreen.routeName:
                      return MaterialPageRoute(
                        builder: (_) => SetupRoundScreen(roomId: args),
                      );
                    case WaitingClueScreen.routeName:
                      return MaterialPageRoute(
                        builder: (_) => WaitingClueScreen(roomId: args),
                      );
                    case GuessRoundScreen.routeName:
                      return MaterialPageRoute(
                        builder: (_) => GuessRoundScreen(roomId: args),
                      );
                    case ResultScreen.routeName:
                      return MaterialPageRoute(
                        builder: (_) => ResultScreen(roomId: args),
                      );
                    case ScoreboardScreen.routeName:
                      return MaterialPageRoute(
                        builder: (_) => ScoreboardScreen(roomId: args),
                      );
                    case MatchSummaryScreen.routeName:
                      return MaterialPageRoute(
                        builder: (_) => MatchSummaryScreen(roomId: args),
                      );
                    case DiceRollScreen.routeName: // Add the new DiceRollScreen route
                      return MaterialPageRoute(
                        builder: (_) => DiceRollScreen(roomId: args),
                      );
                    default:
                      return null; // let Flutter show an error
                  }
                },
              );
            },
          );
        },
      ),
    );
  }
}

/// A widget that navigates to the correct screen based on room status and player role.
class RoomNavigator extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();

    // Listen to the current user's authentication state to ensure currentUserUid is available
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, authSnapshot) {
        if (!authSnapshot.hasData || authSnapshot.data!.uid.isEmpty) {
          // If no user is authenticated, direct to HomeScreen
          return const HomeScreen();
        }

        final currentUserUid = authSnapshot.data!.uid;

        // NEW: Listen to the user's currentRoomId from their settings
        return StreamBuilder<String?>(
          stream: fb.listenCurrentUserRoomId(),
          builder: (context, currentRoomIdSnap) {
            final String? roomId = currentRoomIdSnap.data;

            if (roomId == null || roomId.isEmpty) {
              // If no room ID is stored for the current user, or it's cleared, go to Home Screen
              return const HomeScreen();
            }

            // Now, listen to the specific room document using the retrieved roomId
            return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
              stream: FirebaseFirestore.instance.collection('rooms').doc(roomId).snapshots(),
              builder: (context, roomDocSnapshot) {
                if (!roomDocSnapshot.hasData || roomDocSnapshot.data == null || !roomDocSnapshot.data!.exists) {
                  // If room document doesn't exist, has no data, or current user is not in playerOrder anymore (edge case for cleanup)
                  // Invalidate local roomId and go to Home Screen
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    fb.saveCurrentRoomId(null); // Clear invalid room ID
                  });
                  return const HomeScreen();
                }

                final roomData = roomDocSnapshot.data!.data()!;
                final roomStatus = roomData['status'] as String? ?? 'lobby';
                final playerOrder = List<String>.from(roomData['playerOrder'] ?? []);

                // Additional check: If current user is no longer in playerOrder (e.g., forcefully removed or left),
                // invalidate local roomId and go to Home Screen. This is a robust check.
                if (!playerOrder.contains(currentUserUid)) {
                   WidgetsBinding.instance.addPostFrameCallback((_) {
                    fb.saveCurrentRoomId(null); // Clear invalid room ID
                  });
                  return const HomeScreen();
                }


                return StreamBuilder<Role>(
                  stream: fb.listenMyRole(roomId), // listenMyRole uses the current round's roles
                  builder: (context, roleSnap) {
                    if (!roleSnap.hasData) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    final myRole = roleSnap.data!;

                    // --- Navigation Logic based on Room Status and Role ---
                    switch (roomStatus) {
                      case 'lobby':
                      case 'ready_phase': // Both states direct to ReadyScreen
                        return ReadyScreen(roomId: roomId);
                      case 'dice_roll': // New: Show dice roll screen
                        return DiceRollScreen(roomId: roomId);
                      case 'clue_submission':
                        if (myRole == Role.Navigator) {
                          return SetupRoundScreen(roomId: roomId);
                        } else {
                          return WaitingClueScreen(roomId: roomId);
                        }
                      case 'guessing':
                        return GuessRoundScreen(roomId: roomId);
                      case 'round_end':
                        return ResultScreen(roomId: roomId);
                      case 'match_end':
                        return MatchSummaryScreen(roomId: roomId);
                      default:
                        // This case handles unexpected status values or initial loading states
                        return const Center(child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Colors.red))); // Indicate error/unexpected
                    }
                  },
                );
              },
            );
          },
        );
      },
    );
  }
}
