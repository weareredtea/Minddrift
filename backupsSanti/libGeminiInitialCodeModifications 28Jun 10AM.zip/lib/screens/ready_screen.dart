// lib/screens/ready_screen.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/firebase_service.dart';
import '../models/player_status.dart';
import '../models/round.dart'; // Import Role enum
import 'home_screen.dart'; // Import for navigating back to home
import 'scoreboard_screen.dart'; // Import for navigating to scoreboard

class ReadyScreen extends StatefulWidget {
  static const routeName = '/ready';
  final String roomId;
  const ReadyScreen({Key? key, required this.roomId}) : super(key: key);

  @override
  State<ReadyScreen> createState() => _ReadyScreenState();
}

class _ReadyScreenState extends State<ReadyScreen> {
  // Flag to ensure the dialog/navigation for last player only happens once
  bool _showingLastPlayerDialog = false;
  bool _navigatedToRoundStart = false; // New flag to prevent multiple navigations

  @override
  void initState() {
    super.initState();
    _setupPlayerListeners();
  }

  void _setupPlayerListeners() {
    // Listen for player departures to show toast messages
    context.read<FirebaseService>().listenForPlayerDepartures(widget.roomId).listen((playerName) {
      if (playerName != null && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$playerName has exited the room.'),
            duration: const Duration(seconds: 2),
          ),
        );
      }
    });

    // Listen for last player standing scenario
    context.read<FirebaseService>().listenToLastPlayerStatus(widget.roomId).listen((status) async {
      final onlinePlayerCount = status['onlinePlayerCount'] as int;
      final isLastPlayer = status['isLastPlayer'] as bool;
      final currentUserDisplayName = status['currentUserDisplayName'] as String;
      final roomId = widget.roomId;

      // Get room data to check if current user is creator and it's the very beginning
      final roomSnap = await context.read<FirebaseService>().roomDocRef(roomId).get();
      final roomData = roomSnap.data();
      final isCreator = roomData?['creator'] == context.read<FirebaseService>().currentUserUid;
      final currentRoundNumber = roomData?['currentRoundNumber'] as int? ?? 0;

      // Suppress dialog if creator and it's the very first round (currentRoundNumber is 0 or 1)
      final isInitialRoomCreation = isCreator && currentRoundNumber <= 1;

      if (isLastPlayer && onlinePlayerCount == 1 && !_showingLastPlayerDialog && mounted && !isInitialRoomCreation) {
        setState(() {
          _showingLastPlayerDialog = true; // Set flag to prevent multiple dialogs
        });
        _showLastPlayerDialog(context, currentUserDisplayName, widget.roomId);
      } else if (!isLastPlayer && onlinePlayerCount > 1 && _showingLastPlayerDialog) {
        // If more players join, dismiss the dialog if it's showing
        if (Navigator.of(context).canPop()) {
          Navigator.of(context).pop();
        }
        setState(() {
          _showingLastPlayerDialog = false;
        });
      }
    });
  }

  Future<void> _showLastPlayerDialog(BuildContext context, String displayName, String roomId) async {
    await showDialog<void>(
      context: context,
      barrierDismissible: false, // User must tap a button
      builder: (BuildContext dialogContext) {
        final fb = dialogContext.read<FirebaseService>();
        return AlertDialog(
          title: const Text('You are the Last Player!'),
          content: Text('All other players have exited the room. You can invite other players, view the total score, or exit.'),
          actions: <Widget>[
            TextButton(
              child: const Text('Invite Friends'),
              onPressed: () {
                // TODO: Implement invite friends functionality (e.g., share room ID)
                Navigator.of(dialogContext).pop(); // Dismiss dialog
                setState(() { _showingLastPlayerDialog = false; }); // Reset flag
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Share room ID: $roomId')),
                );
              },
            ),
            TextButton(
              child: const Text('View Scoreboard'),
              onPressed: () {
                Navigator.of(dialogContext).pop(); // Dismiss dialog
                setState(() { _showingLastPlayerDialog = false; }); // Reset flag
                Navigator.pushNamed(context, ScoreboardScreen.routeName, arguments: roomId);
              },
            ),
            TextButton(
              child: const Text('Exit to Home'),
              onPressed: () async {
                await fb.leaveRoom(roomId); // Make current player leave the room
                Navigator.of(dialogContext).pop(); // Dismiss dialog
                setState(() { _showingLastPlayerDialog = false; }); // Reset flag
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => const HomeScreen()),
                  (Route<dynamic> route) => false,
                );
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _showExitConfirmationDialog(BuildContext context, String roomId) async {
    final fb = context.read<FirebaseService>();
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // User must tap a button
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Exit Game?'),
          content: const Text('Are you sure you want to exit this room? Other players will be notified.'),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(dialogContext).pop();
              },
            ),
            TextButton(
              child: const Text('Exit'),
              onPressed: () async {
                await fb.leaveRoom(roomId);
                Navigator.of(dialogContext).pop();
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => const HomeScreen()),
                  (Route<dynamic> route) => false,
                );
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();
    final roomId = widget.roomId;
    final myUid = fb.currentUserUid;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Get Ready'),
        actions: [
          IconButton(
            icon: const Icon(Icons.exit_to_app),
            onPressed: () => _showExitConfirmationDialog(context, roomId),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text('Room Code: $roomId',
                style:
                    const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),

            // 1) List of players + their ready-/online icons
            Expanded(
              child: StreamBuilder<List<PlayerStatus>>(
                stream: fb.listenToReady(roomId),
                builder: (ctx, snap) {
                  if (!snap.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  final players = snap.requireData;
                  // Sort players to keep consistent order
                  players.sort((a, b) => a.displayName.compareTo(b.displayName));

                  return ListView(
                    children: players.map((p) {
                      return ListTile(
                        leading: Icon(
                          p.ready
                              ? Icons.check_circle
                              : Icons.radio_button_unchecked,
                          color: p.ready ? Colors.green : null,
                        ),
                        title: Text(p.displayName),
                        trailing: Icon(
                          p.online ? Icons.circle : Icons.circle_outlined,
                          size: 12,
                          color: p.online ? Colors.green : Colors.red,
                        ),
                      );
                    }).toList(),
                  );
                },
              ),
            ),

            const SizedBox(height: 12),

            // 2) My “I’m Ready” toggle button
            StreamBuilder<List<PlayerStatus>>(
              stream: fb.listenToReady(roomId),
              builder: (ctx, snap) {
                if (!snap.hasData) return const SizedBox();
                final allPlayers = snap.requireData;
                final me = allPlayers.firstWhere(
                  (p) => p.uid == myUid,
                  orElse: () => PlayerStatus(
                    uid: myUid,
                    displayName: 'You',
                    ready: false,
                    online: true,
                    guessReady: false, // Added guessReady for consistency
                  ),
                );
                final allReady = allPlayers.every((p) => p.ready); // Check all players

                // Auto-advance logic: If all players are ready and we haven't navigated yet
                if (allReady && !_navigatedToRoundStart) {
                  WidgetsBinding.instance.addPostFrameCallback((_) async {
                    if (mounted && !_navigatedToRoundStart) {
                      setState(() => _navigatedToRoundStart = true); // Set flag to prevent re-trigger
                      await fb.startRound(roomId); // Auto-start the round
                    }
                  });
                }

                return ElevatedButton(
                  onPressed: _navigatedToRoundStart // Disable button if navigation is already triggered
                      ? null
                      : () => fb.setReady(roomId, !me.ready), // Toggle my own ready status
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: Text(
                    me.ready ? 'Cancel Ready' : 'I\'m Ready',
                    style: const TextStyle(fontSize: 18),
                  ),
                );
              },
            ),

            const SizedBox(height: 16),

            // Host-only “All Ready — Start Round” button (Removed as per request)
            // Replaced by auto-advance logic above.
          ],
        ),
      ),
    );
  }
}
