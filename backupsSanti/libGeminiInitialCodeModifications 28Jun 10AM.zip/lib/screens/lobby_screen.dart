// lib/screens/lobby_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/firebase_service.dart';
import '../pigeon/pigeon.dart';
import 'ready_screen.dart';

class LobbyScreen extends StatelessWidget {
  static const routeName = '/lobby';
  final String roomId;
  const LobbyScreen({Key? key, required this.roomId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();

    return Scaffold(
      appBar: AppBar(title: const Text('Lobby')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text('Room Code: $roomId',
                style:
                    const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            FutureBuilder<List<PigeonUserDetails>>(
              future: fb.fetchPlayers(roomId),
              builder: (ctx, snap) {
                if (snap.connectionState != ConnectionState.done) {
                  return const Center(child: CircularProgressIndicator());
                }
                final players = snap.data ?? [];
                if (players.isEmpty) {
                  return const Text('No one has joined yet.');
                }
                return Expanded(
                  child: ListView(
                    children: players
                        .map((u) => ListTile(
                              leading: const Icon(Icons.person),
                              title: Text(u.displayName),
                              subtitle: Text('UID: ${u.uid}'),
                            ))
                        .toList(),
                  ),
                );
              },
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacementNamed(
                  context,
                  ReadyScreen.routeName,
                  arguments: roomId,
                );
              },
              child: const Text('Proceed to Ready'),
            ),
          ],
        ),
      ),
    );
  }
}
