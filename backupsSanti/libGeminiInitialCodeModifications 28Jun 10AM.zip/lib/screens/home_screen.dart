// lib/screens/home_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/firebase_service.dart';
import 'ready_screen.dart';
import 'settings_screen.dart'; // Import the new settings screen

class HomeScreen extends StatefulWidget {
  static const routeName = '/';
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _roomCtrl = TextEditingController();
  bool _loading = false;
  // SaboteurEnabled and DiceRollEnabled will now be managed by SettingsScreen
  // These initial values are just defaults before loading from settings (if persistent)

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Wavelength Clone'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const SettingsScreen()),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center, // Center the content vertically
          crossAxisAlignment: CrossAxisAlignment.stretch, // Stretch buttons horizontally
          children: [
            // Moved SaboteurEnabled and DiceRollEnabled switches to SettingsScreen
            // These buttons will now get preferences from FirebaseService (if stored/loaded)
            ElevatedButton(
              onPressed: _loading
                  ? null
                  : () async {
                      setState(() => _loading = true);
                      // Fetch current settings from FirebaseService to pass to createRoom
                      final roomSettings = await fb.fetchRoomCreationSettings();
                      final id = (await fb.createRoom(
                        roomSettings['saboteurEnabled'] ?? false,
                        roomSettings['diceRollEnabled'] ?? false,
                      )).toUpperCase();
                      setState(() => _loading = false);
                      Navigator.pushReplacementNamed(
                        context,
                        ReadyScreen.routeName,
                        arguments: id,
                      );
                    },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: _loading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text(
                      'Create Room',
                      style: TextStyle(fontSize: 18),
                    ),
            ),
            const SizedBox(height: 24),

            const Text(
              'OR',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.grey),
            ),
            const SizedBox(height: 24),

            // Join Room Section
            TextField(
              controller: _roomCtrl,
              decoration: InputDecoration(
                labelText: 'Enter Room ID',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              ),
              textCapitalization: TextCapitalization.characters,
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _loading
                  ? null
                  : () async {
                      setState(() => _loading = true);
                      final code = _roomCtrl.text.trim().toUpperCase();
                      final exists = await fb.roomExists(code);
                      setState(() => _loading = false);
                      if (!exists) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Room not found')),
                        );
                        return;
                      }
                      await fb.joinRoom(code);
                      Navigator.pushReplacementNamed(
                        context,
                        ReadyScreen.routeName,
                        arguments: code,
                      );
                    },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: _loading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text(
                      'Join Room',
                      style: TextStyle(fontSize: 18),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
