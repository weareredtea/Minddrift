// lib/screens/guess_round_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../services/firebase_service.dart';
import '../widgets/slider_dial.dart';
import '../models/player_status.dart'; // Corrected import path
import '../models/round.dart'; // Import Round model for category, clue, roles
import 'home_screen.dart'; // Import for navigating back to home
import 'scoreboard_screen.dart'; // Import for navigating to scoreboard
import 'result_screen.dart'; // Import ResultScreen for direct navigation (used by RoomNavigator)

class GuessRoundScreen extends StatefulWidget {
  static const routeName = '/guess';
  final String roomId;
  const GuessRoundScreen({Key? key, required this.roomId}) : super(key: key);

  @override
  State<GuessRoundScreen> createState() => _GuessRoundScreenState();
}

class _GuessRoundScreenState extends State<GuessRoundScreen> {
  bool _showingLastPlayerDialog = false;

  @override
  void initState() {
    super.initState();
    _setupPlayerListeners();
  }

  void _setupPlayerListeners() {
    // Listen for player departures to show toast messages
    context.read<FirebaseService>().listenForPlayerDepartures(widget.roomId).listen((playerName) {
      if (playerName != null && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$playerName has exited the room.'),
            duration: const Duration(seconds: 2),
          ),
        );
      }
    });

    // Listen for last player standing scenario
    context.read<FirebaseService>().listenToLastPlayerStatus(widget.roomId).listen((status) async {
      final onlinePlayerCount = status['onlinePlayerCount'] as int;
      final isLastPlayer = status['isLastPlayer'] as bool;
      final currentUserDisplayName = status['currentUserDisplayName'] as String;
      final roomId = widget.roomId;

      // Get room data to check if current user is creator and it's the very beginning
      final roomSnap = await context.read<FirebaseService>().roomDocRef(roomId).get();
      final roomData = roomSnap.data();
      final isCreator = roomData?['creator'] == context.read<FirebaseService>().currentUserUid;
      final currentRoundNumber = roomData?['currentRoundNumber'] as int? ?? 0;

      // Suppress dialog if creator and it's the very first round (currentRoundNumber is 0 or 1)
      final isInitialRoomCreation = isCreator && currentRoundNumber <= 1;

      if (isLastPlayer && onlinePlayerCount == 1 && !_showingLastPlayerDialog && mounted && !isInitialRoomCreation) {
        setState(() {
          _showingLastPlayerDialog = true;
        });
        _showLastPlayerDialog(context, currentUserDisplayName, widget.roomId);
      } else if (!isLastPlayer && onlinePlayerCount > 1 && _showingLastPlayerDialog) {
        // If more players join, dismiss the dialog if it's showing
        if (Navigator.of(context).canPop()) {
          Navigator.of(context).pop();
        }
        setState(() {
          _showingLastPlayerDialog = false;
        });
      }
    });
  }

  Future<void> _showLastPlayerDialog(BuildContext context, String displayName, String roomId) async {
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext dialogContext) {
        final fb = dialogContext.read<FirebaseService>();
        return AlertDialog(
          title: const Text('You are the Last Player!'),
          content: Text('All other players have exited the room. You can invite other players, view the total score, or exit.'),
          actions: <Widget>[
            TextButton(
              child: const Text('Invite Friends'),
              onPressed: () {
                Navigator.of(dialogContext).pop();
                setState(() { _showingLastPlayerDialog = false; });
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Share room ID: $roomId')),
                );
              },
            ),
            TextButton(
              child: const Text('View Scoreboard'),
              onPressed: () {
                Navigator.of(dialogContext).pop();
                setState(() { _showingLastPlayerDialog = false; });
                Navigator.pushNamed(context, ScoreboardScreen.routeName, arguments: roomId);
              },
            ),
            TextButton(
              child: const Text('Exit to Home'),
              onPressed: () async {
                await fb.leaveRoom(roomId);
                Navigator.of(dialogContext).pop();
                setState(() { _showingLastPlayerDialog = false; });
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => const HomeScreen()),
                  (Route<dynamic> route) => false,
                );
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _showExitConfirmationDialog(BuildContext context, String roomId) async {
    final fb = context.read<FirebaseService>();
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Exit Game?'),
          content: const Text('Are you sure you want to exit this room? Other players will be notified.'),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(dialogContext).pop();
              },
            ),
            TextButton(
              child: const Text('Exit'),
              onPressed: () async {
                await fb.leaveRoom(roomId);
                Navigator.of(dialogContext).pop();
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => const HomeScreen()),
                  (Route<dynamic> route) => false,
                );
              },
            ),
          ],
        );
      },
    );
  }

  // Helper to get a string representation of the effect
  String _getEffectDescription(Effect? effect) {
    if (effect == null || effect == Effect.none) {
      return '';
    }
    switch (effect) {
      case Effect.doubleScore: return 'Double Score!';
      case Effect.halfScore: return 'Half Score!';
      case Effect.token: return 'Navigator gets a Token!';
      case Effect.reverseSlider: return 'Reverse Slider!';
      case Effect.noClue: return 'No Clue!';
      case Effect.blindGuess: return 'Blind Guess!';
      default: return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    final fb = context.read<FirebaseService>();
    final uid = fb.currentUserUid;
    final roomId = widget.roomId;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Seekers: Make the Guess'),
        actions: [
          IconButton(
            icon: const Icon(Icons.exit_to_app),
            onPressed: () => _showExitConfirmationDialog(context, roomId),
          ),
        ],
      ),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>( // Listen to room document directly
        stream: fb.roomDocRef(roomId).snapshots(),
        builder: (ctx, roomSnap) {
          if (!roomSnap.hasData || roomSnap.data?.data() == null) {
            return const Center(child: CircularProgressIndicator());
          }

          final roomData = roomSnap.data!.data()!;
          final roomStatus = roomData['status'] as String? ?? 'guessing'; // Default to guessing

          // If room status is 'round_end', return an empty box. RoomNavigator will handle navigation.
          if (roomStatus == 'round_end') {
            return const SizedBox();
          }

          // Otherwise, continue building the GuessRoundScreen content
          return StreamBuilder<Round>(
            stream: fb.listenCurrentRound(roomId),
            builder: (ctx, snap) {
              if (!snap.hasData || snap.data!.clue == null || snap.data!.categoryLeft == null) {
                return const CircularProgressIndicator();
              }
              final currentRound = snap.data!;
              final clue = currentRound.clue!;
              final categoryLeft = currentRound.categoryLeft!;
              final categoryRight = currentRound.categoryRight!;
              final effect = currentRound.effect; // Get the effect
              final effectDescription = _getEffectDescription(effect);

              return Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    // Clue and Category display
                    Text(
                      'Clue: "$clue"',
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    if (effect != null && effect != Effect.none)
                      Padding(
                        padding: const EdgeInsets.only(top: 8.0),
                        child: Text(
                          'Effect: $effectDescription',
                          style: TextStyle(fontSize: 18, fontStyle: FontStyle.italic, color: Colors.deepOrange.shade700, fontWeight: FontWeight.bold),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    if (effect == Effect.blindGuess)
                      Padding(
                        padding: const EdgeInsets.only(top: 8.0),
                        child: Text(
                          'Effect active: "Blind Guess!" - Slider values are hidden.',
                          style: TextStyle(color: Colors.red[700], fontStyle: FontStyle.italic),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    if (effect == Effect.reverseSlider)
                      Padding(
                        padding: const EdgeInsets.only(top: 8.0),
                        child: Text(
                          'Effect active: "Reverse Slider!" - Slider direction is reversed.',
                          style: TextStyle(color: Colors.red[700], fontStyle: FontStyle.italic),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          categoryLeft,
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                        ),
                        Text(
                          categoryRight,
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),

                    const SizedBox(height: 24),

                    // Shared slider
                    StreamBuilder<int>(
                      stream: fb.listenGroupGuess(roomId),
                      builder: (ctx, snap) {
                        final pos = (snap.data ?? 50).toDouble();

                        return StreamBuilder<Round>( // Stream for current round to get effect and my role
                          stream: fb.listenCurrentRound(roomId),
                          builder: (context, roundSnap) {
                            if (!roundSnap.hasData) return const SizedBox();
                            final currentRound = roundSnap.data!;
                            final myRole = currentRound.roles?[uid];
                            final isBlindGuessEffect = currentRound.effect == Effect.blindGuess;
                            final isReverseSliderEffect = currentRound.effect == Effect.reverseSlider;

                            // Adjust slider value if reverse effect is active
                            final displayPos = isReverseSliderEffect ? (100 - pos) : pos;

                            return SliderDial(
                              value: displayPos, // Display adjusted position
                              divisions: 100,
                              // Only Seekers and Saboteurs can change the slider
                              onChanged: myRole == Role.Navigator
                                  ? (_) {} // No-op for Navigator
                                  : (v) => fb.updateGroupGuess(
                                        roomId,
                                        isReverseSliderEffect ? (100 - v) : v, // Send actual position to Firestore
                                      ),
                              showValue: !isBlindGuessEffect, // Hide value if Blind Guess is active
                            );
                          }
                        );
                      },
                    ),

                    const SizedBox(height: 16),

                    // Seekers ready list + toggle button
                    Expanded(
                      child: StreamBuilder<List<PlayerStatus>>(
                        stream: fb.listenGuessReady(roomId),
                        builder: (ctx, ss) {
                          if (!ss.hasData) {
                            return const Center(child: CircularProgressIndicator());
                          }
                          final players = ss.data!;
                          // Sort players for consistent display
                          players.sort((a, b) => a.displayName.compareTo(b.displayName));

                          final me = players.firstWhere(
                            (p) => p.uid == uid,
                            orElse: () => PlayerStatus(
                              uid: uid,
                              displayName: 'You',
                              ready: false,
                              online: true,
                              guessReady: false,
                            ),
                          );

                          // Get the current player's role
                          return StreamBuilder<Role>(
                            stream: fb.listenMyRole(roomId),
                            builder: (context, roleSnap) {
                              if (!roleSnap.hasData) {
                                return const Center(child: CircularProgressIndicator());
                              }
                              final myRole = roleSnap.data!;

                              return Column(
                                children: [
                                  Expanded(
                                    child: ListView(
                                      children: players.map((p) {
                                        return ListTile(
                                          leading: Icon(
                                            p.guessReady // Use guessReady here
                                                ? Icons.check_circle
                                                : Icons.radio_button_unchecked,
                                            color: p.guessReady ? Colors.green : null,
                                          ),
                                          title: Text(
                                            p.displayName +
                                            (p.role != null ? ' (${p.role})' : ''), // Use p.role directly
                                          ),
                                          trailing: Icon(
                                            p.online
                                                ? Icons.circle
                                                : Icons.circle_outlined,
                                            size: 12,
                                            color: p.online ? Colors.green : Colors.red,
                                          ),
                                        );
                                      }).toList(),
                                    ),
                                  ),

                                  const SizedBox(height: 12),

                                  // My “I’m Ready” toggle button for guessing
                                  if (myRole != Role.Navigator) // Navigator doesn't need to be guess ready
                                    ElevatedButton(
                                      onPressed: () =>
                                          fb.setGuessReady(roomId, !me.guessReady), // Use setGuessReady
                                      style: ElevatedButton.styleFrom(
                                        padding: const EdgeInsets.symmetric(vertical: 16),
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                      ),
                                      child: Text(
                                        me.guessReady ? 'Cancel Guess' : 'Confirm Group Guess',
                                        style: const TextStyle(fontSize: 18),
                                      ),
                                    ),
                                  const SizedBox(height: 12),

                                  // Auto-advance logic (only for Host)
                                  StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                                    stream: fb.roomDocRef(roomId).snapshots(), // Re-using existing roomSnap stream
                                    builder: (ctx, hostRoomSnap) {
                                      if (!hostRoomSnap.hasData) return const SizedBox();
                                      final hostRoomData = hostRoomSnap.requireData.data() ?? {};
                                      final hostUid = hostRoomData['creator'] as String? ?? '';

                                      // Only the host will trigger finalizeRound
                                      if (hostUid != uid) return const SizedBox(); // Nothing to show/do for non-hosts

                                      // Listen for all seekers readiness on host side
                                      return StreamBuilder<bool>(
                                        stream: fb.listenAllSeekersReady(roomId),
                                        builder: (ctx2, allReadySnap) {
                                          if (!allReadySnap.hasData || allReadySnap.data! == false) {
                                            // Not all ready, or no data, show a waiting message (optional)
                                            return Text(
                                              'Waiting for all Seekers to confirm...',
                                              style: TextStyle(fontStyle: FontStyle.italic, color: Colors.grey[600]),
                                              textAlign: TextAlign.center,
                                            );
                                          }

                                          // If all seekers are ready, and it's the host, trigger finalizeRound
                                          WidgetsBinding.instance.addPostFrameCallback((_) {
                                            final currentRoomStatus = hostRoomData['status'] as String? ?? '';
                                            if (currentRoomStatus == 'guessing') {
                                              fb.finalizeRound(roomId);
                                            }
                                          });
                                          return const SizedBox(); // Host button is removed, auto-advances
                                        },
                                      );
                                    },
                                  ),
                                ],
                              );
                            }
                          );
                        },
                      ),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}
