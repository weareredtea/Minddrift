import 'dart:math';
import 'dart:convert'; // For jsonDecode

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:rxdart/rxdart.dart'; // Import rxdart for stream combination

import '../models/player_status.dart';
import '../models/round.dart';
import '../models/round_history_entry.dart';
import '../pigeon/pigeon.dart'; // Assuming PigeonUserDetails is here

class FirebaseService with ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final Random _rnd = Random();

  // These variables are provided by the Canvas environment directly.
  // We declare them here and check for their presence.
  String? _canvasAppId;
  String? _canvasInitialAuthToken;

  // Constructor to initialize Firebase if not already.
  FirebaseService() {
    _initializeFirebaseAndAuth();
  }

  // --- Firebase Initialization and Authentication ---
  Future<void> _initializeFirebaseAndAuth() async {
    // Access global Canvas variables directly.
    // They are available as global top-level variables in the Flutter environment.
    try {
      _canvasAppId = const String.fromEnvironment('app_id', defaultValue: 'default-app-id');
      _canvasInitialAuthToken = const String.fromEnvironment('initial_auth_token');
    } catch (e) {
      // Fallback for non-Canvas environments or during build
      _canvasAppId = 'default-app-id';
      _canvasInitialAuthToken = null;
    }


    final auth = FirebaseAuth.instance;

    // Use _canvasInitialAuthToken for custom token sign-in if available
    if (_canvasInitialAuthToken != null && _canvasInitialAuthToken!.isNotEmpty) {
      try {
        await auth.signInWithCustomToken(_canvasInitialAuthToken!);
        print('Signed in with custom token.');
      } catch (e) {
        print('Error signing in with custom token: $e');
        await auth.signInAnonymously();
        print('Signed in anonymously as fallback.');
      }
    } else {
      await auth.signInAnonymously();
      print('Signed in anonymously (no custom token).');
    }

    // Listen to auth state changes and notify listeners
    _auth.authStateChanges().listen((User? user) {
      if (user != null) {
        print('User is signed in: ${user.uid}');
      } else {
        print('User is currently signed out.');
      }
      notifyListeners(); // Notify UI when auth state changes
    });
  }

  // Ensure currentUserUid is only accessed when user is truly signed in
  String get currentUserUid => _auth.currentUser?.uid ?? '';

  // Generate a random 4-character room code
  String _randomCode(int n) =>
      List.generate(n, (_) => 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'[_rnd.nextInt(36)])
          .join();

  Future<bool> roomExists(String roomId) async =>
      (await _db.collection('rooms').doc(roomId).get()).exists;

  // --- Room Management ---

  /// Creates a new room with initial settings, including saboteur preference.
  Future<String> createRoom(bool saboteurEnabled) async {
    final userCredential = await _auth.signInAnonymously(); // Returns UserCredential
    final user = userCredential.user!; // Get the User object from UserCredential
    String roomId;
    do {
      roomId = _randomCode(4);
    } while (await roomExists(roomId)); // Await is correct here

    final roomRef = _db.collection('rooms').doc(roomId);

    await roomRef.set({
      'creator': user.uid,
      'createdAt': FieldValue.serverTimestamp(),
      'status': 'lobby', // Initial status
      'saboteurEnabled': saboteurEnabled,
      'currentRoundNumber': 0, // Starts at 0, increments to 1 for first round
      'navigatorRotationIndex': 0, // Index for playerOrder
      'playerOrder': [user.uid], // Host is first in order
      'usedCategoryIds': [],
      'saboteurId': null, // Assigned later if enabled
    });

    // Add host as a player
    await roomRef.collection('players').doc(user.uid).set({
      'displayName': 'Player-${user.uid.substring(0, 4)}', // More readable default name
      'isReady': false, // For ready phase
      'guessReady': false, // For guess phase
      'online': true,
      'lastSeen': FieldValue.serverTimestamp(),
      'totalScore': 0,
    });

    // Seed categories for the room
    await _seedCategories(roomId);
    notifyListeners();
    return roomId;
  }

  /// Joins an existing room.
  Future<void> joinRoom(String roomId) async {
    final userCredential = await _auth.signInAnonymously(); // Returns UserCredential
    final user = userCredential.user!; // Get the User object from UserCredential

    final roomRef = _db.collection('rooms').doc(roomId);
    final playerRef = roomRef.collection('players').doc(user.uid);

    // Add player to the room if not already there, or update online status
    await playerRef.set({
      'displayName': 'Player-${user.uid.substring(0, 4)}', // Default display name, can be updated by user
      'isReady': false,
      'guessReady': false,
      'online': true,
      'lastSeen': FieldValue.serverTimestamp(),
      'totalScore': 0,
    }, SetOptions(merge: true));

    // Add player UID to playerOrder if not already present
    await roomRef.update({
      'playerOrder': FieldValue.arrayUnion([user.uid]),
    });

    // Set online status to false when disconnecting (basic presence)
    // Use .snapshots() method for listening
    playerRef.snapshots().listen((snapshot) { // Corrected: .snapshots() method
      if (!snapshot.exists) {
        // Player document was deleted (e.g., left room)
        return;
      }
      // Access data directly as Map<String, dynamic>
      final data = snapshot.data()!; // snapshot.data() is already Map<String, dynamic>
      if (snapshot.metadata.isFromCache || !data.containsKey('online')) {
        return;
      }
      final online = data['online'] as bool? ?? false;
      if (!online) {
        // If player goes offline, try to mark them offline after a delay
        Future.delayed(const Duration(seconds: 10), () async {
          final currentSnapshot = await playerRef.get();
          if (currentSnapshot.exists && currentSnapshot.data()?['online'] == false) {
            await playerRef.update({'isReady': false, 'guessReady': false});
          }
        });
      }
    });

    notifyListeners();
  }

  // --- Category Management ---

  // Seeds predefined categories into a room's subcollection.
  Future<void> _seedCategories(String roomId) async {
    final cats = [
      {'id':'hot_cold','left':'HOT','right':'COLD'},
      {'id':'calm_noisy','left':'CALM','right':'NOISY'},
      {'id':'soft_rough','left':'SOFT','right':'ROUGH'},
      {'id':'fast_slow','left':'FAST','right':'SLOW'},
      {'id':'light_dark','left':'LIGHT','right':'DARK'},
      {'id':'sweet_sour','left':'SWEET','right':'SOUR'},
      {'id':'big_small','left':'BIG','right':'SMALL'},
      {'id':'strong_weak','left':'STRONG','right':'WEAK'},
      {'id':'old_new','left':'OLD','right':'NEW'},
      {'id':'happy_sad','left':'HAPPY','right':'SAD'},
      {'id':'brave_cowardly','left':'BRAVE','right':'COWARDLY'},
      {'id':'clean_dirty','left':'CLEAN','right':'DIRTY'},
      {'id':'empty_full','left':'EMPTY','right':'FULL'},
      {'id':'funny_serious','left':'FUNNY','right':'SERIOUS'},
      {'id':'hard_easy','left':'HARD','right':'EASY'},
      {'id':'heavy_light','left':'HEAVY','right':'LIGHT'},
      {'id':'kind_cruel','left':'KIND','right':'CRUEL'},
      {'id':'loud_quiet','left':'LOUD','right':'QUIET'},
      {'id':'open_closed','left':'OPEN','right':'CLOSED'},
      {'id':'rich_poor','left':'RICH','right':'POOR'},
      {'id':'safe_dangerous','left':'SAFE','right':'DANGEROUS'},
      {'id':'short_tall','left':'SHORT','right':'TALL'},
      {'id':'smooth_bumpy','left':'SMOOTH','right':'BUMPY'},
      {'id':'straight_curved','left':'STRAIGHT','right':'CURVED'},
      {'id':'thick_thin','left':'THICK','right':'THIN'},
      {'id':'tight_loose','left':'TIGHT','right':'LOOSE'},
      {'id':'true_false','left':'TRUE','right':'FALSE'},
      {'id':'wet_dry','left':'WET','right':'DRY'},
      {'id':'wide_narrow','left':'WIDE','right':'NARROW'},
      {'id':'young_old','left':'YOUNG','right':'OLD'},
    ];
    final col = _db.collection('rooms').doc(roomId).collection('categories');
    for (var c in cats) {
      await col.doc(c['id']!).set(c);
    }
  }

  // --- Round Specific References ---

  DocumentReference<Map<String,dynamic>> roomDocRef(String roomId) =>
      _db.collection('rooms').doc(roomId);

  DocumentReference<Map<String,dynamic>> roundDocRef(String roomId) =>
      _db.collection('rooms').doc(roomId).collection('rounds').doc('current');

  CollectionReference<Map<String,dynamic>> playersColRef(String roomId) =>
      _db.collection('rooms').doc(roomId).collection('players');

  // --- Ready Phase (Lobby) ---

  /// Sets player's ready status in the lobby.
  Future<void> setReady(String roomId, bool ready) => playersColRef(roomId)
      .doc(currentUserUid)
      .update({'isReady': ready});

  /// Listens to all players' ready status for the lobby.
  Stream<List<PlayerStatus>> listenToReady(String roomId) =>
      playersColRef(roomId).snapshots().map((snap) {
        return snap.docs.map((d) => PlayerStatus.fromSnapshot(d)).toList();
      });

  // --- New Round Setup Helper ---

  /// Helper method to set up roles, category, and secret for a new round.
  Future<void> _setupNewRoundState(String roomId, {required bool isFirstRound}) async {
    final roomSnap = await roomDocRef(roomId).get();
    if (!roomSnap.exists) return;
    final roomData = roomSnap.data()!;

    List<String> playerOrder = List<String>.from(roomData['playerOrder'] ?? []);
    List<String> usedCategoryIds = List<String>.from(roomData['usedCategoryIds'] ?? []);
    final saboteurEnabled = roomData['saboteurEnabled'] as bool? ?? false;

    // Ensure playerOrder is populated and shuffled once at the start of a match
    if (playerOrder.isEmpty || isFirstRound) { // Re-shuffle if it's the very first round.
      final playersSnap = await playersColRef(roomId).get();
      playerOrder = playersSnap.docs.map((d) => d.id).toList();
      playerOrder.shuffle();
    }

    final currentRoundNumber = (roomData['currentRoundNumber'] as int) + 1;
    final navigatorRotationIndex = roomData['navigatorRotationIndex'] as int;
    final navigatorUid = playerOrder[navigatorRotationIndex % playerOrder.length];

    // Determine Saboteur (if enabled and not already assigned for the match)
    String? saboteurUid = roomData['saboteurId'] as String?;
    if (saboteurEnabled && saboteurUid == null) {
      final potentialSaboteurs = playerOrder.where((uid) => uid != navigatorUid).toList();
      if (potentialSaboteurs.isNotEmpty) {
        saboteurUid = potentialSaboteurs[_rnd.nextInt(potentialSaboteurs.length)];
      }
    }

    // Assign roles to all players and reset readiness for the round
    final batch = _db.batch();
    final playersSnap = await playersColRef(roomId).get();
    for (var doc in playersSnap.docs) {
      final playerUid = doc.id;
      Role role;
      if (playerUid == navigatorUid) {
        role = Role.Navigator;
      } else if (saboteurEnabled && playerUid == saboteurUid) {
        role = Role.Saboteur;
      } else {
        role = Role.Seeker;
      }
      batch.update(playersColRef(roomId).doc(playerUid), {
        'role': role.toString().split('.').last,
        'isReady': false, // Reset 'isReady' for the next "ready for round" phase (if any, or just to clear)
        'guessReady': false, // Reset 'guessReady' for the guessing phase
      });
    }

    // Select category
    final allCategoriesSnap = await _db.collection('rooms').doc(roomId).collection('categories').get();
    final availableCategories = allCategoriesSnap.docs
        .where((doc) => !usedCategoryIds.contains(doc.id))
        .toList();

    String selectedCategoryId;
    Map<String, dynamic> selectedCategoryData;

    if (availableCategories.isEmpty) {
      // All categories used, reset and pick from all
      usedCategoryIds = [];
      final randomCategoryDoc = allCategoriesSnap.docs[_rnd.nextInt(allCategoriesSnap.docs.length)];
      selectedCategoryId = randomCategoryDoc.id;
      selectedCategoryData = randomCategoryDoc.data();
    } else {
      final randomCategoryDoc = availableCategories[_rnd.nextInt(availableCategories.length)];
      selectedCategoryId = randomCategoryDoc.id;
      selectedCategoryData = randomCategoryDoc.data();
    }
    usedCategoryIds.add(selectedCategoryId);

    // Generate secret position
    final secretPosition = _rnd.nextInt(101); // 0 to 100

    // Update current round document and main room document in a batch
    batch.set(roundDocRef(roomId), {
      'secretPosition': secretPosition,
      'categoryLeft': selectedCategoryData['left'],
      'categoryRight': selectedCategoryData['right'],
      'clue': null,
      'guesses': {},
      'roles': playersSnap.docs.asMap().map((index, doc) {
        final playerUid = doc.id;
        Role role;
        if (playerUid == navigatorUid) {
          role = Role.Navigator;
        } else if (saboteurEnabled && playerUid == saboteurUid) {
          role = Role.Saboteur;
        } else {
          role = Role.Seeker;
        }
        return MapEntry(playerUid, role.toString().split('.').last);
      }),
      'groupGuessPosition': 50,
      'score': null,
      'roundStartedTimestamp': FieldValue.serverTimestamp(),
    });

    batch.update(roomDocRef(roomId), {
      'status': 'clue_submission', // Direct to clue submission after round setup
      'currentRoundNumber': currentRoundNumber,
      'navigatorRotationIndex': (navigatorRotationIndex + 1) % playerOrder.length,
      'saboteurId': saboteurUid,
      'playerOrder': playerOrder,
      'usedCategoryIds': usedCategoryIds,
      'currentCategoryId': selectedCategoryId,
      'currentTrueSliderPosition': secretPosition,
      'roundStartedTimestamp': FieldValue.serverTimestamp(),
    });

    await batch.commit();
  }


  // --- Round Start (Host Action) ---

  /// Host starts the first round: assigns roles, secret position, category.
  Future<void> startRound(String roomId) async {
    // This is for the very first round only, triggered from ReadyScreen
    await _setupNewRoundState(roomId, isFirstRound: true);
  }

  /// Listens to the overall room status to navigate players.
  Stream<String> listenRoomStatus(String roomId) {
    return roomDocRef(roomId).snapshots().map((snap) {
      final data = snap.data();
      return (data?['status'] as String?) ?? 'lobby';
    });
  }

  /// Fetches current player's role for the current round.
  Stream<Role> listenMyRole(String roomId) {
    return roundDocRef(roomId).snapshots().map((snap) {
      final data = snap.data();
      final rolesMap = (data?['roles'] as Map<String, dynamic>?)?.cast<String, String>() ?? {};
      final myRoleString = rolesMap[currentUserUid];
      return Role.values.firstWhere(
        (e) => e.toString().split('.').last.toLowerCase() == myRoleString?.toLowerCase(),
        orElse: () => Role.Seeker, // Default to Seeker if not found
      );
    });
  }

  // --- Clue Submission Phase ---

  /// Submits the Navigator's clue. Secret position is already set at startRound.
  Future<void> submitClue(String roomId, int secret, String clue) async {
    await roundDocRef(roomId).set({
      'clue': clue,
    }, SetOptions(merge: true));

    // After clue is submitted, transition room status to 'guessing'
    await roomDocRef(roomId).update({'status': 'guessing'});
  }

  /// Listens to current round details (clue, secret, category).
  Stream<Round> listenCurrentRound(String roomId) {
    return roundDocRef(roomId).snapshots().map((snap) {
      return Round.fromMap(snap.data() ?? {});
    });
  }

  // --- Guessing Phase ---

  /// Updates the shared group guess slider position.
  Future<void> updateGroupGuess(String roomId, double pos) {
    // Round to nearest integer for consistency as Firestore stores int
    return roundDocRef(roomId)
        .update({'groupGuessPosition': pos.round()});
  }

  /// Listens to the shared group guess slider position.
  Stream<int> listenGroupGuess(String roomId) =>
      roundDocRef(roomId).snapshots().map((snap) {
        final data = snap.data();
        return (data?['groupGuessPosition'] as num?)?.toInt() ?? 50;
      });

  /// Sets player's ready status during the guessing phase.
  Future<void> setGuessReady(String roomId, bool ready) => playersColRef(roomId)
      .doc(currentUserUid)
      .update({'guessReady': ready});

  /// Listens to all players' `guessReady` status for the guessing phase.
  Stream<List<PlayerStatus>> listenGuessReady(String roomId) =>
      playersColRef(roomId).snapshots().map((snap) {
        return snap.docs
            .map((d) => PlayerStatus.fromSnapshot(d))
            .toList();
      });

  /// Listens to check if all seekers (and saboteur) are ready with their guess.
  Stream<bool> listenAllSeekersReady(String roomId) {
    return Rx.combineLatest2(
      playersColRef(roomId).snapshots().map((snap) => snap.docs.map((d) => PlayerStatus.fromSnapshot(d)).toList()),
      roundDocRef(roomId).snapshots().map((snap) => Round.fromMap(snap.data() ?? {})),
      (List<PlayerStatus> allPlayers, Round currentRound) {
        final rolesMap = currentRound.roles ?? {};
        final currentNavigatorUid = rolesMap.entries
            .firstWhereOrNull((entry) => entry.value == Role.Navigator)
            ?.key;

        // Filter for players who are NOT the navigator
        final playersToCheck = allPlayers.where((p) => p.uid != currentNavigatorUid).toList();

        // All non-navigators must be guessReady
        return playersToCheck.every((p) => p.guessReady);
      },
    );
  }

  /// Calculates and saves the round score, then transitions to result screen.
  Future<void> finalizeRound(String roomId) async {
    final roomSnap = await roomDocRef(roomId).get(); // Re-fetch room data to get currentRoundNumber
    if (!roomSnap.exists) return;
    final roomData = roomSnap.data()!; // Now roomData is in scope and refers to the main room document
    final currentRoundNumberInRoom = roomData['currentRoundNumber'] as int;

    final roundSnap = await roundDocRef(roomId).get();
    if (!roundSnap.exists) return;
    final roundData = roundSnap.data()!;

    final secret = (roundData['secretPosition'] as num?)?.toInt() ?? 0;
    final guess = (roundData['groupGuessPosition'] as num?)?.toInt() ?? 0;
    final distance = (secret - guess).abs();

    int score;
    if (distance <= 5) {
      score = 6;
    } else if (distance <= 10) {
      score = 3;
    } else if (distance <= 20) {
      score = 1;
    } else {
      score = 0;
    }

    // Update round document with calculated score
    await roundDocRef(roomId).update({
      'score': score,
      'roundEndedTimestamp': FieldValue.serverTimestamp(),
    });

    // Update total scores for players (Navigator and Seekers get points)
    final batch = _db.batch();
    final playersSnap = await playersColRef(roomId).get();
    final rolesInRound = (roundData['roles'] as Map<String, dynamic>?)?.cast<String, String>() ?? {};

    for (var doc in playersSnap.docs) {
      final playerUid = doc.id;
      final playerRoleString = rolesInRound[playerUid];
      // Only Navigator and Seekers gain points from correct guess
      if (playerRoleString == Role.Navigator.toString().split('.').last ||
          playerRoleString == Role.Seeker.toString().split('.').last) {
        batch.update(playersColRef(roomId).doc(playerUid), {
          'totalScore': FieldValue.increment(score),
        });
      }
      // Reset guessReady for next round
      batch.update(playersColRef(roomId).doc(playerUid), {'guessReady': false});
    }
    await batch.commit();

    // Add entry to round history
    final roomHistoryCollection = roomDocRef(roomId).collection('history');
    await roomHistoryCollection.add({
      'roundNumber': currentRoundNumberInRoom, // Use the correct variable from the room data
      'secret': secret,
      'guess': guess,
      'score': score,
      'timestamp': FieldValue.serverTimestamp(),
    });

    // Transition room status to 'round_end'
    await roomDocRef(roomId).update({'status': 'round_end'});
  }

  // --- Result Screen & Next Round / Match End ---

  /// Fetches players with their total scores for match summary.
  Future<List<PigeonUserDetails>> fetchPlayersWithScores(String roomId) async {
    final col = await playersColRef(roomId).get();
    return col.docs.map((doc) {
      final data = doc.data();
      return PigeonUserDetails(
        uid: doc.id,
        displayName: data['displayName'] as String? ?? 'Anonymous',
        totalScore: data['totalScore'] as int? ?? 0,
      );
    }).toList();
  }

  /// Fetches historical rounds for the scoreboard.
  Future<List<RoundHistoryEntry>> fetchHistory(String roomId) async {
    final snap = await roomDocRef(roomId)
        .collection('history')
        .orderBy('timestamp', descending: true)
        .get();
    return snap.docs.map((d) => RoundHistoryEntry.fromMap(d.data())).toList();
  }

  /// Host increments round number and resets room state for a new round.
  Future<void> incrementRoundAndReset(String roomId) async {
    final roomSnap = await roomDocRef(roomId).get();
    if (!roomSnap.exists) return;
    final roomData = roomSnap.data()!;
    final currentRoundNumber = roomData['currentRoundNumber'] as int;

    if (currentRoundNumber >= 5) { // Match ends after 5 rounds
      await roomDocRef(roomId).update({'status': 'match_end'});
    } else {
      // Instead of going back to 'ready_phase', we directly set up the next round
      // and transition to 'clue_submission'
      await _setupNewRoundState(roomId, isFirstRound: false);

      // Reset all players' `isReady` state for the new round
      final batch = _db.batch();
      final playersSnap = await playersColRef(roomId).get();
      for (var doc in playersSnap.docs) {
        batch.update(playersColRef(roomId).doc(doc.id), {
          'isReady': false, // Reset for the next round's confirmation
          'guessReady': false, // Ensure this is also reset
        });
      }
      await batch.commit();
    }
  }

  // --- Player Presence (Basic) ---

  /// Updates a player's online status.
  Future<void> updateOnlineStatus(String roomId, bool online) async {
    if (_auth.currentUser == null) return; // Only update if signed in
    await playersColRef(roomId).doc(currentUserUid).update({
      'online': online,
      'lastSeen': FieldValue.serverTimestamp(),
    });
  }

  /// Fetch all players in this room as PigeonUserDetails (for lobby/summary).
  Future<List<PigeonUserDetails>> fetchPlayers(String roomId) async {
    final col = await playersColRef(roomId).get();
    return col.docs.map((doc) {
      final data = doc.data();
      return PigeonUserDetails(
        uid: doc.id,
        displayName: data['displayName'] as String? ?? 'Anonymous',
      );
    }).toList();
  }

  // --- Clean Up ---
  @override
  void dispose() {
    // Implement any necessary stream cancellations or resource cleanup here
    super.dispose();
  }
}

// Extension to provide firstWhereOrNull, similar to what you might find in collection packages
extension IterableExtension<T> on Iterable<T> {
  T? firstWhereOrNull(bool Function(T element) test) {
    for (var element in this) {
      if (test(element)) {
        return element;
      }
    }
    return null;
  }
}
